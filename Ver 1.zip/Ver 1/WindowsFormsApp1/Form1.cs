// =====================================================================
//  ИС "Деканат" (Вариант 7). Версия 1 - базовая (без авторизации).
//
//  ВАЖНО: интерфейс этой формы строится ПРОГРАММНО (метод BuildUi()),
//  поэтому в дизайнере Visual Studio форма выглядит ПУСТОЙ - это
//  нормально и ошибкой не является. Проверять надо запуском (F5).
//
//  Реализованный функционал:
//   * Справочные таблицы: категории, дисциплины, группы,
//     преподаватели, студенты, расписание
//   * Добавление записей через отдельные формы (с проверками данных)
//   * Составление расписания: проверка даты, защита от дублей,
//     правило "два экзамена в один день"
//   * Отчёт: длительность сессии (сохранение в файл)
//
//  Структура файла:
//    Db    - строка подключения к БД Access
//    Ui    - фабрика элементов интерфейса
//    Form1 - главное окно (таблицы, операции)
//    FormAdd* - формы добавления записей во все таблицы
//    FormSessionDuration - отчёт
// =====================================================================
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    // ---------------------------------------------------------------
    //  Строка подключения. БД Деканат_Вариант7.accdb лежит в bin\Debug
    // ---------------------------------------------------------------
    static class Db
    {
        public static readonly string ConnStr =
            "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\\Деканат_Вариант7.accdb";
    }

    // ---------------------------------------------------------------
    //  Модуль проверки (МодульПроверки из диаграммы последовательности)
    // ---------------------------------------------------------------
    static class ValidationModule
    {
        // Проверка корректности даты
        public static bool ValidDate(DateTime d)
        {
            return d.Year >= 2000 && d.Year <= 2100;
        }

        // Типы мероприятий группы на указанную дату
        // (для проверки "два экзамена в один день")
        public static List<string> EventTypesOnDate(OleDbConnection con, string groupId, DateTime date)
        {
            List<string> res = new List<string>();
            using (OleDbCommand cmd = new OleDbCommand(
                "SELECT ControlType FROM tbl_SessionsSchedule WHERE GroupID=? AND ExamDate=?", con))
            {
                cmd.Parameters.AddWithValue("?", groupId);
                cmd.Parameters.AddWithValue("?", date.Date);
                using (OleDbDataReader rd = cmd.ExecuteReader())
                    while (rd.Read())
                        res.Add(rd[0] == DBNull.Value ? "" : Convert.ToString(rd[0]));
            }
            return res;
        }

        // Проверка "два экзамена в один день":
        // у группы уже есть экзамен на эту дату?
        public static bool HasExamOnDate(OleDbConnection con, string groupId, DateTime date)
        {
            foreach (string t in EventTypesOnDate(con, groupId, date))
                if (t.ToLower().Contains("экзам"))
                    return true;
            return false;
        }
    }

    // ---------------------------------------------------------------
    //  Фабрика элементов интерфейса
    // ---------------------------------------------------------------
    static class Ui
    {
        // Диалоговое окно по центру родителя, фиксированные границы
        public static void Dialog(Form f, string title, int w, int h)
        {
            f.Text = title;
            f.FormBorderStyle = FormBorderStyle.FixedDialog;
            f.MaximizeBox = false;
            f.MinimizeBox = false;
            f.StartPosition = FormStartPosition.CenterParent;
            f.ClientSize = new Size(w, h);
            f.Font = new Font("Segoe UI", 9F);
            f.ShowInTaskbar = false;
        }

        public static Label MkLabel(string text, int y)
        {
            Label l = new Label();
            l.Location = new Point(12, y + 3);
            l.AutoSize = true;
            l.Text = text;
            return l;
        }

        public static TextBox MkTextBox(int x, int y, int w)
        {
            TextBox t = new TextBox();
            t.Location = new Point(x, y);
            t.Width = w;
            return t;
        }

        public static Button MkButton(string text, int x, int y, int w)
        {
            Button b = new Button();
            b.Text = text;
            b.Location = new Point(x, y);
            b.Size = new Size(w, 28);
            return b;
        }

        public static DataGridView MkGrid(int x, int y, int w, int h)
        {
            DataGridView g = new DataGridView();
            g.Location = new Point(x, y);
            g.Size = new Size(w, h);
            g.ReadOnly = true;
            g.AllowUserToAddRows = false;
            g.AllowUserToDeleteRows = false;
            g.AllowUserToResizeRows = false;
            g.RowHeadersVisible = false;
            g.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            g.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            g.BackgroundColor = SystemColors.Window;
            g.MultiSelect = false;
            g.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            return g;
        }

        // Кнопки "Сохранить" / "Отмена" в правом нижнем углу формы
        public static void Buttons(Form f, EventHandler okHandler)
        {
            Button ok = MkButton("Сохранить", f.ClientSize.Width - 195, f.ClientSize.Height - 38, 85);
            ok.Click += okHandler;
            Button cancel = MkButton("Отмена", f.ClientSize.Width - 102, f.ClientSize.Height - 38, 85);
            cancel.Click += delegate { f.DialogResult = DialogResult.Cancel; f.Close(); };
            f.AcceptButton = ok;
            f.CancelButton = cancel;
            f.Controls.Add(ok);
            f.Controls.Add(cancel);
        }

        public static void Warn(string msg, string title)
        {
            MessageBox.Show(msg, title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        public static void Error(Exception ex)
        {
            MessageBox.Show("Ошибка:\n" + ex.Message, "Ошибка",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        // Сохранение отчёта в текстовый файл (формирование отчёта)
        public static void SaveTextReport(Form owner, string defaultName, string header, string[] lines)
        {
            using (SaveFileDialog sfd = new SaveFileDialog())
            {
                sfd.Filter = "Текстовые файлы (*.txt)|*.txt|Все файлы (*.*)|*.*";
                sfd.FileName = defaultName;
                if (sfd.ShowDialog(owner) != DialogResult.OK) return;
                StringBuilder sb = new StringBuilder();
                sb.AppendLine(header);
                foreach (string s in lines) sb.AppendLine(s);
                File.WriteAllText(sfd.FileName, sb.ToString(), Encoding.UTF8);
                MessageBox.Show(owner, "Сохранено в файл:\n" + sfd.FileName, "Отчёт",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }

    // ================================================================
    //  Главное окно программы
    // ================================================================
    public partial class Form1 : Form
    {
        // ---------- описание таблиц ----------
        private class TableInfo
        {
            public string Title;      // название в списке
            public string SelectSql;  // запрос выборки
            public string RealTable;  // имя таблицы в БД
            public string KeyColumn;  // первичный ключ
            public bool TextKey;      // текстовый ключ (группы)
        }

        private static readonly TableInfo[] Tables = new TableInfo[]
        {
            new TableInfo { Title="Категории",    SelectSql="SELECT * FROM tbl_Categories",        RealTable="tbl_Categories",        KeyColumn="CategoryID" },
            new TableInfo { Title="Дисциплины",   SelectSql="SELECT * FROM tbl_Discipline",        RealTable="tbl_Discipline",        KeyColumn="DisciplineID" },
            new TableInfo { Title="Группы",       SelectSql="SELECT * FROM tbl_Groups",            RealTable="tbl_Groups",            KeyColumn="GroupID", TextKey=true },
            new TableInfo { Title="Преподаватели",SelectSql="SELECT * FROM tbl_Teacher",           RealTable="tbl_Teacher",           KeyColumn="TeacherID" },
            new TableInfo { Title="Студенты",     SelectSql="SELECT * FROM tbl_Students",          RealTable="tbl_Students",          KeyColumn="StudentID" },
            new TableInfo { Title="Расписание",   SelectSql="SELECT * FROM tbl_SessionsSchedule",  RealTable="tbl_SessionsSchedule",  KeyColumn="ScheduleID" }
        };

        // ---------- поля ----------
        private string currentTitle = "";
        private OleDbDataAdapter adapter = null;
        private OleDbCommandBuilder builder = null;
        private DataTable table = null;

        private ComboBox cbTables;
        private Button btnAdd, btnSave, btnDelete, btnRefresh;
        private Button btnSession;
        private DataGridView grid;

        // ---------- конструктор ----------
        public Form1()
        {
            InitializeComponent();
            // В режиме дизайнера Visual Studio интерфейс не строим и к БД не обращаемся
            if (LicenseManager.UsageMode == LicenseUsageMode.Designtime) return;
            BuildUi();
        }

        // ---------- построение интерфейса ----------
        private void BuildUi()
        {
            Text = "ИС Деканат (Вариант 7) - базовая версия";
            ClientSize = new Size(1020, 660);
            StartPosition = FormStartPosition.CenterScreen;
            Font = new Font("Segoe UI", 9F);

            Label lblTable = new Label();
            lblTable.Location = new Point(12, 55);
            lblTable.AutoSize = true;
            lblTable.Text = "Таблица:";
            Controls.Add(lblTable);

            cbTables = new ComboBox();
            cbTables.Location = new Point(70, 52);
            cbTables.Size = new Size(250, 24);
            cbTables.DropDownStyle = ComboBoxStyle.DropDownList;
            cbTables.SelectedIndexChanged += delegate
            {
                currentTitle = Convert.ToString(cbTables.SelectedItem);
                LoadTable();
            };
            Controls.Add(cbTables);

            btnAdd = new Button();
            btnAdd.Text = "Добавить...";
            btnAdd.Location = new Point(330, 50);
            btnAdd.Size = new Size(150, 30);
            btnAdd.Click += BtnAdd_Click;
            Controls.Add(btnAdd);

            btnSave = new Button();
            btnSave.Text = "Сохранить изменения";
            btnSave.Location = new Point(488, 50);
            btnSave.Size = new Size(150, 30);
            btnSave.Click += BtnSave_Click;
            Controls.Add(btnSave);

            btnDelete = new Button();
            btnDelete.Text = "Удалить";
            btnDelete.Location = new Point(646, 50);
            btnDelete.Size = new Size(130, 30);
            btnDelete.Click += BtnDelete_Click;
            Controls.Add(btnDelete);

            btnRefresh = new Button();
            btnRefresh.Text = "Обновить";
            btnRefresh.Location = new Point(784, 50);
            btnRefresh.Size = new Size(110, 30);
            btnRefresh.Click += delegate { LoadTable(); };
            Controls.Add(btnRefresh);

            // отчёт "Длительность сессии"
            btnSession = new Button();
            btnSession.Text = "Длительность сессии";
            btnSession.Location = new Point(12, 88);
            btnSession.Size = new Size(170, 30);
            btnSession.Click += delegate
            {
                using (FormSessionDuration f = new FormSessionDuration()) f.ShowDialog(this);
            };
            Controls.Add(btnSession);

            grid = Ui.MkGrid(12, 126, 996, 522);
            Controls.Add(grid);

            // заполнение списка таблиц: в базовой версии доступны все
            foreach (TableInfo t in Tables) cbTables.Items.Add(t.Title);
            int idx = cbTables.Items.IndexOf("Расписание");
            if (idx < 0) idx = 0;
            if (cbTables.Items.Count > 0) cbTables.SelectedIndex = idx;
        }

        private TableInfo CurrentTable
        {
            get { return Tables.FirstOrDefault(t => t.Title == currentTitle); }
        }

        // ---------- загрузка таблицы ----------
        private void LoadTable()
        {
            TableInfo ti = CurrentTable;
            if (ti == null) { grid.DataSource = null; return; }

            try
            {
                table = new DataTable();
                adapter = new OleDbDataAdapter(ti.SelectSql, Db.ConnStr);
                adapter.MissingSchemaAction = MissingSchemaAction.AddWithKey;
                builder = new OleDbCommandBuilder(adapter);
                builder.QuotePrefix = "[";
                builder.QuoteSuffix = "]";
                adapter.Fill(table);
                grid.ReadOnly = false;
                grid.DataSource = table;
                StyleDateColumns();
                // ключевое поле (счётчик) не редактируется вручную
                if (table.Columns.Count > 0 && table.Columns[0].AutoIncrement)
                {
                    grid.Columns[0].ReadOnly = true;
                    grid.Columns[0].DefaultCellStyle.BackColor = Color.WhiteSmoke;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных:\n" + ex.Message, "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void StyleDateColumns()
        {
            foreach (DataGridViewColumn c in grid.Columns)
                if (c.ValueType == typeof(DateTime))
                    c.DefaultCellStyle.Format = "dd.MM.yyyy";
        }

        // ---------- обработчики кнопок ----------
        private void BtnAdd_Click(object sender, EventArgs e)
        {
            TableInfo ti = CurrentTable;
            if (ti == null) return;
            Form addForm = null;
            switch (ti.Title)
            {
                case "Категории":     addForm = new FormAddCategory(); break;
                case "Дисциплины":    addForm = new FormAddDiscipline(); break;
                case "Группы":        addForm = new FormAddGroup(); break;
                case "Преподаватели": addForm = new FormAddTeacher(); break;
                case "Студенты":      addForm = new FormAddStudent(); break;
                case "Расписание":    addForm = new FormAddSchedule(); break;
            }
            if (addForm == null) return;
            if (addForm.ShowDialog(this) == DialogResult.OK) LoadTable();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            TableInfo ti = CurrentTable;
            if (ti == null) return;
            grid.EndEdit();
            if (table != null) BindingContext[table].EndCurrentEdit();
            try
            {
                adapter.Update(table);
                MessageBox.Show("Изменения успешно сохранены.", "Сохранение",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadTable();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка сохранения:\n" + ex.Message, "Сохранение",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                LoadTable();
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            TableInfo ti = CurrentTable;
            if (ti == null) return;
            if (grid.CurrentRow == null)
            {
                MessageBox.Show("Выберите запись для удаления!", "Удаление",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            DataGridViewRow row = grid.CurrentRow;
            object keyVal = row.Cells[0].Value;
            DialogResult res = MessageBox.Show("Вы уверены, что хотите удалить выбранную запись?",
                "Удаление", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res != DialogResult.Yes) return;
            try
            {
                using (OleDbConnection con = new OleDbConnection(Db.ConnStr))
                {
                    con.Open();
                    using (OleDbCommand cmd = new OleDbCommand(
                        "DELETE FROM " + ti.RealTable + " WHERE " + ti.KeyColumn + "=?", con))
                    {
                        if (ti.TextKey) cmd.Parameters.AddWithValue("?", Convert.ToString(keyVal));
                        else cmd.Parameters.AddWithValue("?", Convert.ToInt32(keyVal));
                        cmd.ExecuteNonQuery();
                    }
                }
                LoadTable();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка удаления:\n" + ex.Message, "Удаление",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ---------- общие помощники ----------
        // Комбобокс с данными из БД; editable=true - можно вводить текст
        // вручную + автозаполнение (для групп)
        public static ComboBox MakeCombo(string sql, string display, string value, bool editable)
        {
            ComboBox cb = new ComboBox();
            DataTable dt = new DataTable();
            using (OleDbDataAdapter da = new OleDbDataAdapter(sql, Db.ConnStr))
                da.Fill(dt);
            cb.DataSource = dt;
            cb.DisplayMember = display;
            cb.ValueMember = value;
            if (editable)
            {
                cb.DropDownStyle = ComboBoxStyle.DropDown;
                cb.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                cb.AutoCompleteSource = AutoCompleteSource.CustomSource;
                AutoCompleteStringCollection src = new AutoCompleteStringCollection();
                foreach (DataRow r in dt.Rows)
                    src.Add(Convert.ToString(r[display]));
                cb.AutoCompleteCustomSource = src;
            }
            else
            {
                cb.DropDownStyle = ComboBoxStyle.DropDownList;
            }
            return cb;
        }

        // Проверка группы: точное совпадение -> без учёта регистра ->
        // предложение создать группу "на лету"
        public static string ResolveGroup(ComboBox cb, IWin32Window owner)
        {
            string txt = cb.Text.Trim();
            if (txt.Length == 0)
            {
                MessageBox.Show(owner, "Выберите или введите группу (например, АЛ-17а)!", "Группа",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return null;
            }
            List<string> ids = new List<string>();
            using (OleDbConnection con = new OleDbConnection(Db.ConnStr))
            {
                con.Open();
                using (OleDbCommand cmd = new OleDbCommand("SELECT GroupID FROM tbl_Groups", con))
                using (OleDbDataReader rd = cmd.ExecuteReader())
                    while (rd.Read()) ids.Add(Convert.ToString(rd[0]));
            }
            foreach (string g in ids)
                if (g == txt) { cb.Text = g; return g; }
            foreach (string g in ids)
                if (string.Equals(g, txt, StringComparison.OrdinalIgnoreCase)) { cb.Text = g; return g; }
            DialogResult res = MessageBox.Show(owner,
                "Группа \"" + txt + "\" не найдена в базе данных.\nСоздать её сейчас?",
                "Группа", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res == DialogResult.Yes)
            {
                using (FormAddGroup f = new FormAddGroup(txt))
                {
                    if (f.ShowDialog(owner) == DialogResult.OK && !string.IsNullOrEmpty(f.CreatedGroupId))
                    {
                        cb.Text = f.CreatedGroupId;
                        return f.CreatedGroupId;
                    }
                }
            }
            return null;
        }
    }

    // ================================================================
    //  Формы добавления записей
    // ================================================================

    // Новая категория дисциплин
    public class FormAddCategory : Form
    {
        private TextBox txtName;

        public FormAddCategory()
        {
            Ui.Dialog(this, "Новая категория", 400, 110);
            Controls.Add(Ui.MkLabel("Название категории:", 14));
            txtName = Ui.MkTextBox(150, 12, 230);
            Controls.Add(txtName);
            Ui.Buttons(this, BtnOk_Click);
        }

        private void BtnOk_Click(object sender, EventArgs e)
        {
            string name = txtName.Text.Trim();
            if (name.Length == 0) { Ui.Warn("Введите название категории!", Text); return; }
            try
            {
                using (OleDbConnection con = new OleDbConnection(Db.ConnStr))
                {
                    con.Open();
                    object cnt;
                    using (OleDbCommand cmd = new OleDbCommand(
                        "SELECT COUNT(*) FROM tbl_Categories WHERE LCase(CategoryName)=?", con))
                    {
                        cmd.Parameters.AddWithValue("?", name.ToLower());
                        cnt = cmd.ExecuteScalar();
                    }
                    if (Convert.ToInt32(cnt) > 0)
                    {
                        Ui.Warn("Категория \"" + name + "\" уже существует!", Text);
                        return;
                    }
                    using (OleDbCommand cmd = new OleDbCommand(
                        "INSERT INTO tbl_Categories (CategoryName) VALUES (?)", con))
                    {
                        cmd.Parameters.AddWithValue("?", name);
                        cmd.ExecuteNonQuery();
                    }
                }
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex) { Ui.Error(ex); }
        }
    }

    // Новый преподаватель
    public class FormAddTeacher : Form
    {
        private TextBox txtFio, txtDep;

        public FormAddTeacher()
        {
            Ui.Dialog(this, "Новый преподаватель", 400, 143);
            Controls.Add(Ui.MkLabel("ФИО:", 14));
            txtFio = Ui.MkTextBox(150, 12, 230);
            Controls.Add(txtFio);
            Controls.Add(Ui.MkLabel("Кафедра:", 47));
            txtDep = Ui.MkTextBox(150, 45, 230);
            Controls.Add(txtDep);
            Ui.Buttons(this, BtnOk_Click);
        }

        private void BtnOk_Click(object sender, EventArgs e)
        {
            string fio = txtFio.Text.Trim();
            if (fio.Length == 0) { Ui.Warn("Введите ФИО преподавателя!", Text); return; }
            try
            {
                using (OleDbConnection con = new OleDbConnection(Db.ConnStr))
                {
                    con.Open();
                    using (OleDbCommand cmd = new OleDbCommand(
                        "INSERT INTO tbl_Teacher (TeacherFIO, Department) VALUES (?,?)", con))
                    {
                        cmd.Parameters.AddWithValue("?", fio);
                        cmd.Parameters.AddWithValue("?", txtDep.Text.Trim());
                        cmd.ExecuteNonQuery();
                    }
                }
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex) { Ui.Error(ex); }
        }
    }

    // Новая группа (с возможностью предзаполнения шифра)
    public class FormAddGroup : Form
    {
        public string CreatedGroupId = null;
        private TextBox txtId, txtSpec;
        private ComboBox cbCourse;

        public FormAddGroup() : this(null) { }

        public FormAddGroup(string presetId)
        {
            Ui.Dialog(this, "Новая группа", 400, 176);
            Controls.Add(Ui.MkLabel("Шифр группы:", 14));
            txtId = Ui.MkTextBox(150, 12, 230);
            txtId.Text = presetId == null ? "" : presetId;
            Controls.Add(txtId);

            Controls.Add(Ui.MkLabel("Курс:", 47));
            cbCourse = new ComboBox();
            cbCourse.Location = new Point(150, 45);
            cbCourse.Width = 230;
            cbCourse.DropDownStyle = ComboBoxStyle.DropDownList;
            for (int i = 1; i <= 6; i++) cbCourse.Items.Add(i);
            cbCourse.SelectedIndex = 0;
            Controls.Add(cbCourse);

            Controls.Add(Ui.MkLabel("Специальность:", 80));
            txtSpec = Ui.MkTextBox(150, 78, 230);
            Controls.Add(txtSpec);

            Ui.Buttons(this, BtnOk_Click);
        }

        private void BtnOk_Click(object sender, EventArgs e)
        {
            string id = txtId.Text.Trim();
            if (id.Length == 0) { Ui.Warn("Введите шифр группы!", Text); return; }
            try
            {
                using (OleDbConnection con = new OleDbConnection(Db.ConnStr))
                {
                    con.Open();
                    object cnt;
                    using (OleDbCommand cmd = new OleDbCommand(
                        "SELECT COUNT(*) FROM tbl_Groups WHERE LCase(GroupID)=?", con))
                    {
                        cmd.Parameters.AddWithValue("?", id.ToLower());
                        cnt = cmd.ExecuteScalar();
                    }
                    if (Convert.ToInt32(cnt) > 0)
                    {
                        Ui.Warn("Группа \"" + id + "\" уже существует!", Text);
                        return;
                    }
                    using (OleDbCommand cmd = new OleDbCommand(
                        "INSERT INTO tbl_Groups (GroupID, Course, Specialty) VALUES (?,?,?)", con))
                    {
                        cmd.Parameters.AddWithValue("?", id);
                        cmd.Parameters.AddWithValue("?", cbCourse.SelectedItem);
                        cmd.Parameters.AddWithValue("?", txtSpec.Text.Trim());
                        cmd.ExecuteNonQuery();
                    }
                }
                CreatedGroupId = id;
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex) { Ui.Error(ex); }
        }
    }

    // Новый студент (группа: выбор из списка + ручной ввод + автосоздание)
    public class FormAddStudent : Form
    {
        private TextBox txtLast, txtFirst;
        private ComboBox cbGroup;

        public FormAddStudent()
        {
            Ui.Dialog(this, "Новый студент", 400, 176);
            Controls.Add(Ui.MkLabel("Фамилия:", 14));
            txtLast = Ui.MkTextBox(150, 12, 230);
            Controls.Add(txtLast);

            Controls.Add(Ui.MkLabel("Имя:", 47));
            txtFirst = Ui.MkTextBox(150, 45, 230);
            Controls.Add(txtFirst);

            Controls.Add(Ui.MkLabel("Группа:", 80));
            cbGroup = Form1.MakeCombo(
                "SELECT GroupID, GroupID AS GVal FROM tbl_Groups ORDER BY GroupID",
                "GroupID", "GVal", true);
            cbGroup.Location = new Point(150, 78);
            cbGroup.Width = 230;
            Controls.Add(cbGroup);

            Ui.Buttons(this, BtnOk_Click);
        }

        private void BtnOk_Click(object sender, EventArgs e)
        {
            string last = txtLast.Text.Trim();
            string first = txtFirst.Text.Trim();
            if (last.Length == 0) { Ui.Warn("Введите фамилию!", Text); return; }
            if (first.Length == 0) { Ui.Warn("Введите имя!", Text); return; }
            string grp = Form1.ResolveGroup(cbGroup, this);
            if (grp == null) return;
            try
            {
                using (OleDbConnection con = new OleDbConnection(Db.ConnStr))
                {
                    con.Open();
                    using (OleDbCommand cmd = new OleDbCommand(
                        "INSERT INTO tbl_Students (LastName, FirstName, GroupID) VALUES (?,?,?)", con))
                    {
                        cmd.Parameters.AddWithValue("?", last);
                        cmd.Parameters.AddWithValue("?", first);
                        cmd.Parameters.AddWithValue("?", grp);
                        cmd.ExecuteNonQuery();
                    }
                }
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex) { Ui.Error(ex); }
        }
    }

    // Новая дисциплина
    public class FormAddDiscipline : Form
    {
        private TextBox txtName, txtHours;
        private ComboBox cbCat;

        public FormAddDiscipline()
        {
            Ui.Dialog(this, "Новая дисциплина", 400, 176);
            Controls.Add(Ui.MkLabel("Название:", 14));
            txtName = Ui.MkTextBox(150, 12, 230);
            Controls.Add(txtName);

            Controls.Add(Ui.MkLabel("Категория:", 47));
            cbCat = Form1.MakeCombo(
                "SELECT CategoryID, CategoryName FROM tbl_Categories ORDER BY CategoryName",
                "CategoryName", "CategoryID", false);
            cbCat.Location = new Point(150, 45);
            cbCat.Width = 230;
            Controls.Add(cbCat);

            Controls.Add(Ui.MkLabel("Всего часов:", 80));
            txtHours = Ui.MkTextBox(150, 78, 230);
            Controls.Add(txtHours);

            Ui.Buttons(this, BtnOk_Click);
        }

        private void BtnOk_Click(object sender, EventArgs e)
        {
            string name = txtName.Text.Trim();
            if (name.Length == 0) { Ui.Warn("Введите название дисциплины!", Text); return; }
            int hours;
            if (!int.TryParse(txtHours.Text.Trim(), out hours) || hours <= 0)
            {
                Ui.Warn("Всего часов - целое положительное число!", Text);
                return;
            }
            try
            {
                using (OleDbConnection con = new OleDbConnection(Db.ConnStr))
                {
                    con.Open();
                    object cnt;
                    using (OleDbCommand cmd = new OleDbCommand(
                        "SELECT COUNT(*) FROM tbl_Discipline WHERE LCase(DisciplineName)=?", con))
                    {
                        cmd.Parameters.AddWithValue("?", name.ToLower());
                        cnt = cmd.ExecuteScalar();
                    }
                    if (Convert.ToInt32(cnt) > 0)
                    {
                        Ui.Warn("Дисциплина \"" + name + "\" уже существует!", Text);
                        return;
                    }
                    using (OleDbCommand cmd = new OleDbCommand(
                        "INSERT INTO tbl_Discipline (DisciplineName, CategoryID, TotalHours) VALUES (?,?,?)", con))
                    {
                        cmd.Parameters.AddWithValue("?", name);
                        cmd.Parameters.AddWithValue("?",
                            cbCat.SelectedValue == null ? (object)DBNull.Value : cbCat.SelectedValue);
                        cmd.Parameters.AddWithValue("?", hours);
                        cmd.ExecuteNonQuery();
                    }
                }
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex) { Ui.Error(ex); }
        }
    }

    // Новая запись расписания (назначить дату экзамена или зачёта)
    // С проверкой дубля и правилом "два экзамена в один день"
    public class FormAddSchedule : Form
    {
        private ComboBox cbGroup, cbDisc, cbTeach, cbControl;
        private DateTimePicker dtp;
        private Label lblHours;

        public FormAddSchedule()
        {
            Ui.Dialog(this, "Новая запись расписания", 400, 290);

            Controls.Add(Ui.MkLabel("Группа:", 15));
            cbGroup = Form1.MakeCombo(
                "SELECT GroupID, GroupID AS GVal FROM tbl_Groups ORDER BY GroupID",
                "GroupID", "GVal", true);
            cbGroup.Location = new Point(150, 12);
            cbGroup.Width = 230;
            Controls.Add(cbGroup);

            Controls.Add(Ui.MkLabel("Дисциплина:", 48));
            cbDisc = Form1.MakeCombo(
                "SELECT DisciplineID, DisciplineName FROM tbl_Discipline ORDER BY DisciplineName",
                "DisciplineName", "DisciplineID", false);
            cbDisc.Location = new Point(150, 45);
            cbDisc.Width = 230;
            Controls.Add(cbDisc);
            cbDisc.SelectedIndexChanged += delegate { UpdateHours(); };

            Controls.Add(Ui.MkLabel("Преподаватель:", 81));
            cbTeach = Form1.MakeCombo(
                "SELECT TeacherID, TeacherFIO FROM tbl_Teacher ORDER BY TeacherFIO",
                "TeacherFIO", "TeacherID", false);
            cbTeach.Location = new Point(150, 78);
            cbTeach.Width = 230;
            Controls.Add(cbTeach);

            Controls.Add(Ui.MkLabel("Вид контроля:", 114));
            cbControl = new ComboBox();
            cbControl.Location = new Point(150, 111);
            cbControl.Width = 230;
            cbControl.DropDownStyle = ComboBoxStyle.DropDown;
            cbControl.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            cbControl.AutoCompleteSource = AutoCompleteSource.CustomSource;
            List<string> vals = new List<string>();
            try
            {
                DataTable dt = new DataTable();
                using (OleDbDataAdapter da = new OleDbDataAdapter(
                    "SELECT DISTINCT ControlType FROM tbl_SessionsSchedule " +
                    "WHERE ControlType IS NOT NULL ORDER BY ControlType", Db.ConnStr))
                    da.Fill(dt);
                foreach (DataRow r in dt.Rows) vals.Add(Convert.ToString(r[0]));
            }
            catch { }
            foreach (string s in new string[] { "Экзамен", "Зачёт" })
                if (!vals.Contains(s)) vals.Add(s);
            AutoCompleteStringCollection src = new AutoCompleteStringCollection();
            src.AddRange(vals.ToArray());
            cbControl.AutoCompleteCustomSource = src;
            cbControl.Items.AddRange(vals.ToArray());
            Controls.Add(cbControl);

            Controls.Add(Ui.MkLabel("Дата мероприятия:", 147));
            dtp = new DateTimePicker();
            dtp.Location = new Point(150, 144);
            dtp.Width = 230;
            dtp.Format = DateTimePickerFormat.Short;
            dtp.Value = DateTime.Today;
            Controls.Add(dtp);

            // расчёт часов дисциплии (из диаграммы последовательности)
            lblHours = new Label();
            lblHours.Location = new Point(12, 180);
            lblHours.AutoSize = true;
            lblHours.ForeColor = Color.Gray;
            lblHours.Text = "Всего часов по дисциплине: -";
            Controls.Add(lblHours);

            Ui.Buttons(this, BtnOk_Click);
            UpdateHours();
        }

        private void UpdateHours()
        {
            try
            {
                if (cbDisc.SelectedIndex < 0)
                {
                    lblHours.Text = "Всего часов по дисциплине: -";
                    return;
                }
                using (OleDbConnection con = new OleDbConnection(Db.ConnStr))
                {
                    con.Open();
                    using (OleDbCommand cmd = new OleDbCommand(
                        "SELECT TotalHours FROM tbl_Discipline WHERE DisciplineID=?", con))
                    {
                        cmd.Parameters.AddWithValue("?", cbDisc.SelectedValue);
                        object o = cmd.ExecuteScalar();
                        lblHours.Text = "Всего часов по дисциплине: " +
                            (o == null || o == DBNull.Value ? "-" : Convert.ToString(o));
                    }
                }
            }
            catch { lblHours.Text = "Всего часов по дисциплине: -"; }
        }

        private void BtnOk_Click(object sender, EventArgs e)
        {
            string grp = Form1.ResolveGroup(cbGroup, this);
            if (grp == null) return;
            if (cbDisc.SelectedIndex < 0) { Ui.Warn("Выберите дисциплину!", Text); return; }
            if (cbTeach.SelectedIndex < 0) { Ui.Warn("Выберите преподавателя!", Text); return; }
            string ctrl = cbControl.Text.Trim();
            if (ctrl.Length == 0) { Ui.Warn("Введите вид контроля (Экзамен/Зачёт)!", Text); return; }
            DateTime d = dtp.Value.Date;
            if (!ValidationModule.ValidDate(d)) { Ui.Warn("Дата вне допустимого диапазона!", Text); return; }
            try
            {
                using (OleDbConnection con = new OleDbConnection(Db.ConnStr))
                {
                    con.Open();
                    int discId = Convert.ToInt32(cbDisc.SelectedValue);
                    int teachId = Convert.ToInt32(cbTeach.SelectedValue);

                    // проверка дубликата: группа + дисциплина + дата
                    using (OleDbCommand cmd = new OleDbCommand(
                        "SELECT COUNT(*) FROM tbl_SessionsSchedule " +
                        "WHERE GroupID=? AND DisciplineID=? AND ExamDate=?", con))
                    {
                        cmd.Parameters.AddWithValue("?", grp);
                        cmd.Parameters.AddWithValue("?", discId);
                        cmd.Parameters.AddWithValue("?", d);
                        if (Convert.ToInt32(cmd.ExecuteScalar()) > 0)
                        {
                            Ui.Warn("Запись для этой группы, дисциплины и даты уже существует!", Text);
                            return;
                        }
                    }

                    // правило "два экзамена в один день"
                    if (ctrl.ToLower().Contains("экзам") &&
                        ValidationModule.HasExamOnDate(con, grp, d))
                    {
                        MessageBox.Show(this,
                            "У этой группы уже есть экзамен на выбранную дату!\n" +
                            "(правило: два экзамена в один день запрещены)",
                            Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    using (OleDbCommand cmd = new OleDbCommand(
                        "INSERT INTO tbl_SessionsSchedule " +
                        "(GroupID, DisciplineID, TeacherID, ControlType, ExamDate) VALUES (?,?,?,?,?)", con))
                    {
                        cmd.Parameters.AddWithValue("?", grp);
                        cmd.Parameters.AddWithValue("?", discId);
                        cmd.Parameters.AddWithValue("?", teachId);
                        cmd.Parameters.AddWithValue("?", ctrl);
                        cmd.Parameters.AddWithValue("?", d);
                        cmd.ExecuteNonQuery();
                    }
                }
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex) { Ui.Error(ex); }
        }
    }

    // ================================================================
    //  Длительность сессии (запрос из версии 1 + расчёт дней
    //  из диаграммы последовательности)
    // ================================================================
    public class FormSessionDuration : Form
    {
        public FormSessionDuration()
        {
            Text = "Длительность сессии (запрос)";
            Font = new Font("Segoe UI", 9F);
            StartPosition = FormStartPosition.CenterParent;
            ClientSize = new Size(640, 430);

            Label lblInfo = new Label();
            lblInfo.Location = new Point(12, 12);
            lblInfo.AutoSize = false;
            lblInfo.Width = 600;
            lblInfo.Text = "Для каждой группы: начало сессии, конец и длительность в днях (включительно).";
            Controls.Add(lblInfo);

            DataGridView grid = Ui.MkGrid(12, 40, 616, 340);
            Controls.Add(grid);

            Button btnClose = Ui.MkButton("Закрыть", 531, 388, 97);
            btnClose.Click += delegate { Close(); };
            Controls.Add(btnClose);

            try
            {
                DataTable src = new DataTable();
                using (OleDbDataAdapter da = new OleDbDataAdapter(
                    "SELECT GroupID, MIN(ExamDate) AS StartDate, MAX(ExamDate) AS EndDate " +
                    "FROM tbl_SessionsSchedule GROUP BY GroupID ORDER BY GroupID", Db.ConnStr))
                    da.Fill(src);

                DataTable res = new DataTable();
                res.Columns.Add("Группа", typeof(string));
                res.Columns.Add("Начало сессии", typeof(DateTime));
                res.Columns.Add("Конец сессии", typeof(DateTime));
                res.Columns.Add("Длительность, дней", typeof(int));
                foreach (DataRow r in src.Rows)
                {
                    DateTime d1 = Convert.ToDateTime(r["StartDate"]);
                    DateTime d2 = Convert.ToDateTime(r["EndDate"]);
                    res.Rows.Add(r["GroupID"], d1, d2, (d2 - d1).Days + 1);
                }
                grid.DataSource = res;
                foreach (DataGridViewColumn c in grid.Columns)
                    if (c.ValueType == typeof(DateTime))
                        c.DefaultCellStyle.Format = "dd.MM.yyyy";
            }
            catch (Exception ex) { Ui.Error(ex); }
        }
    }
}
