﻿// =====================================================================
//  ИС "Деканат" (Вариант 7). Версия 2 - с авторизацией по ролям.
//
//  ВАЖНО: интерфейс этой формы строится ПРОГРАММНО (метод BuildUi()),
//  поэтому в дизайнере Visual Studio форма выглядит ПУСТОЙ - это
//  нормально и ошибкой не является. Проверять надо запуском (F5):
//  Program.cs -> FormLogin (вход) -> Form1 (главное окно).
//
//  Реализованный функционал (по диаграммам):
//   * Преподаватель: поставить оценку, изменить оценку, изменение
//     журнала, просмотр журнала, просмотр групп, просмотр расписания
//   * Методист: назначить дату экзамена или зачёта, составить
//     расписание, составить списки студентов по группам (части по 30),
//     просмотр журнала, просмотр групп
//   * Журнал (tbl_Journal) создаётся в БД автоматически при запуске
//   * МодульПроверки (ValidationModule): студент в группе, дата,
//     оценка 2-5, "два экзамена в один день"
//   * Просмотр журнала с фильтрами: год, месяц, группа
//   * Отчёты: списки студентов, расписание группы, длительность сессии
//
//  Структура файла:
//    Db               - строка подключения к БД Access
//    ValidationModule - модуль проверки (из диаграммы последовательности)
//    Ui               - фабрика элементов интерфейса
//    Form1            - главное окно (таблицы, права, операции)
//    FormAdd*         - формы добавления записей во все таблицы
//    FormAddGrade / FormEditGrade - поставить / изменить оценку (Журнал)
//    FormListByGroup, FormScheduleReport, FormSessionDuration - отчёты
// =====================================================================
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
namespace WindowsFormsApp1
{
    // ---------------------------------------------------------------
    //  Строка подключения. БД Деканат_Вариант7.accdb лежит в bin\Debug
    // ---------------------------------------------------------------
    static class Db
    {
        public static readonly string ConnStr =
            "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\\Деканат_Вариант7.accdb";
    }

    // ---------------------------------------------------------------
    //  Модуль проверки (МодульПроверки из диаграммы последовательности)
    // ---------------------------------------------------------------
    static class ValidationModule
    {
        // Оценка по 5-балльной системе: от 2 до 5
        public static bool ValidGrade(int g)
        {
            return g >= 2 && g <= 5;
        }

        // Проверка корректности даты
        public static bool ValidDate(DateTime d)
        {
            return d.Year >= 2000 && d.Year <= 2100;
        }

        // Проверка: студент состоит в указанной группе
        public static bool StudentInGroup(OleDbConnection con, int studentId, string groupId)
        {
            using (OleDbCommand cmd = new OleDbCommand(
                "SELECT COUNT(*) FROM tbl_Students WHERE StudentID=? AND GroupID=?", con))
            {
                cmd.Parameters.AddWithValue("?", studentId);
                cmd.Parameters.AddWithValue("?", groupId);
                return Convert.ToInt32(cmd.ExecuteScalar()) > 0;
            }
        }

        // Типы мероприятий группы на указанную дату
        // (для проверки "два экзамена в один день")
        public static List<string> EventTypesOnDate(OleDbConnection con, string groupId, DateTime date)
        {
            List<string> res = new List<string>();
            using (OleDbCommand cmd = new OleDbCommand(
                "SELECT ControlType FROM tbl_SessionsSchedule WHERE GroupID=? AND ExamDate=?", con))
            {
                cmd.Parameters.AddWithValue("?", groupId);
                cmd.Parameters.AddWithValue("?", date.Date);
                using (OleDbDataReader rd = cmd.ExecuteReader())
                    while (rd.Read())
                        res.Add(rd[0] == DBNull.Value ? "" : Convert.ToString(rd[0]));
            }
            return res;
        }

        // Проверка "два экзамена в один день":
        // у группы уже есть экзамен на эту дату?
        public static bool HasExamOnDate(OleDbConnection con, string groupId, DateTime date)
        {
            foreach (string t in EventTypesOnDate(con, groupId, date))
                if (t.ToLower().Contains("экзам"))
                    return true;
            return false;
        }
    }

    // ---------------------------------------------------------------
    //  Фабрика элементов интерфейса
    // ---------------------------------------------------------------
    static class Ui
    {
        // Диалоговое окно по центру родителя, фиксированные границы
        public static void Dialog(Form f, string title, int w, int h)
        {
            f.Text = title;
            f.FormBorderStyle = FormBorderStyle.FixedDialog;
            f.MaximizeBox = false;
            f.MinimizeBox = false;
            f.StartPosition = FormStartPosition.CenterParent;
            f.ClientSize = new Size(w, h);
            f.Font = new Font("Segoe UI", 9F);
            f.ShowInTaskbar = false;
        }

        public static Label MkLabel(string text, int y)
        {
            Label l = new Label();
            l.Location = new Point(12, y + 3);
            l.AutoSize = true;
            l.Text = text;
            return l;
        }

        public static TextBox MkTextBox(int x, int y, int w)
        {
            TextBox t = new TextBox();
            t.Location = new Point(x, y);
            t.Width = w;
            return t;
        }

        public static Button MkButton(string text, int x, int y, int w)
        {
            Button b = new Button();
            b.Text = text;
            b.Location = new Point(x, y);
            b.Size = new Size(w, 28);
            return b;
        }

        // Комбобокс с оценками 5..2 (пятибалльная система)
        public static ComboBox MkGradeCombo(int x, int y)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Val", typeof(int));
            dt.Columns.Add("Name", typeof(string));
            dt.Rows.Add(5, "5 (отлично)");
            dt.Rows.Add(4, "4 (хорошо)");
            dt.Rows.Add(3, "3 (удовлетворительно)");
            dt.Rows.Add(2, "2 (неудовлетворительно)");
            ComboBox cb = new ComboBox();
            cb.Location = new Point(x, y);
            cb.Width = 230;
            cb.DropDownStyle = ComboBoxStyle.DropDownList;
            cb.DataSource = dt;
            cb.DisplayMember = "Name";
            cb.ValueMember = "Val";
            return cb;
        }

        public static DataGridView MkGrid(int x, int y, int w, int h)
        {
            DataGridView g = new DataGridView();
            g.Location = new Point(x, y);
            g.Size = new Size(w, h);
            g.ReadOnly = true;
            g.AllowUserToAddRows = false;
            g.AllowUserToDeleteRows = false;
            g.AllowUserToResizeRows = false;
            g.RowHeadersVisible = false;
            g.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            g.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            g.BackgroundColor = SystemColors.Window;
            g.MultiSelect = false;
            g.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            return g;
        }

        // Кнопки "Сохранить" / "Отмена" в правом нижнем углу формы
        public static void Buttons(Form f, EventHandler okHandler)
        {
            Button ok = MkButton("Сохранить", f.ClientSize.Width - 195, f.ClientSize.Height - 38, 85);
            ok.Click += okHandler;
            Button cancel = MkButton("Отмена", f.ClientSize.Width - 102, f.ClientSize.Height - 38, 85);
            cancel.Click += delegate { f.DialogResult = DialogResult.Cancel; f.Close(); };
            f.AcceptButton = ok;
            f.CancelButton = cancel;
            f.Controls.Add(ok);
            f.Controls.Add(cancel);
        }

        public static void Warn(string msg, string title)
        {
            MessageBox.Show(msg, title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        public static void Error(Exception ex)
        {
            MessageBox.Show("Ошибка:\n" + ex.Message, "Ошибка",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        // Сохранение отчёта в текстовый файл (формирование отчёта)
        public static void SaveTextReport(Form owner, string defaultName, string header, string[] lines)
        {
            using (SaveFileDialog sfd = new SaveFileDialog())
            {
                sfd.Filter = "Текстовые файлы (*.txt)|*.txt|Все файлы (*.*)|*.*";
                sfd.FileName = defaultName;
                if (sfd.ShowDialog(owner) != DialogResult.OK) return;
                StringBuilder sb = new StringBuilder();
                sb.AppendLine(header);
                foreach (string s in lines) sb.AppendLine(s);
                File.WriteAllText(sfd.FileName, sb.ToString(), Encoding.UTF8);
                MessageBox.Show(owner, "Сохранено в файл:\n" + sfd.FileName, "Отчёт",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }

    // ================================================================
    //  Главное окно программы
    // ================================================================
    public partial class Form1 : Form
    {
        // ---------- описание таблиц ----------
        private class TableInfo
        {
            public string Title;      // название в списке
            public string SelectSql;  // запрос выборки
            public string RealTable;  // имя таблицы в БД
            public string KeyColumn;  // первичный ключ
            public bool TextKey;      // текстовый ключ (группы)
            public bool ReadOnlyView; // представление только для чтения (журнал)
        }

        // Журнал - соединение нескольких таблиц (просмотр)
        private const string JournalBaseSql =
            "SELECT j.RecordID AS [Код], s.LastName & ' ' & s.FirstName AS [Студент], " +
            "j.GroupID AS [Группа], d.DisciplineName AS [Дисциплина], " +
            "t.TeacherFIO AS [Преподаватель], j.GradeDate AS [Дата], j.Grade AS [Оценка] " +
            "FROM ((tbl_Journal AS j LEFT JOIN tbl_Students AS s ON j.StudentID = s.StudentID) " +
            "LEFT JOIN tbl_Discipline AS d ON j.DisciplineID = d.DisciplineID) " +
            "LEFT JOIN tbl_Teacher AS t ON j.TeacherID = t.TeacherID";

        private static readonly TableInfo[] Tables = new TableInfo[]
        {
            new TableInfo { Title="Категории",    SelectSql="SELECT * FROM tbl_Categories",        RealTable="tbl_Categories",        KeyColumn="CategoryID" },
            new TableInfo { Title="Дисциплины",   SelectSql="SELECT * FROM tbl_Discipline",        RealTable="tbl_Discipline",        KeyColumn="DisciplineID" },
            new TableInfo { Title="Группы",       SelectSql="SELECT * FROM tbl_Groups",            RealTable="tbl_Groups",            KeyColumn="GroupID", TextKey=true },
            new TableInfo { Title="Преподаватели",SelectSql="SELECT * FROM tbl_Teacher",           RealTable="tbl_Teacher",           KeyColumn="TeacherID" },
            new TableInfo { Title="Студенты",     SelectSql="SELECT * FROM tbl_Students",          RealTable="tbl_Students",          KeyColumn="StudentID" },
            new TableInfo { Title="Расписание",   SelectSql="SELECT * FROM tbl_SessionsSchedule",  RealTable="tbl_SessionsSchedule",  KeyColumn="ScheduleID" },
            new TableInfo { Title="Журнал",       SelectSql=JournalBaseSql + " ORDER BY j.GradeDate, s.LastName", RealTable="tbl_Journal", KeyColumn="RecordID", ReadOnlyView=true },
            new TableInfo { Title="Пользователи", SelectSql="SELECT * FROM tbl_Users",             RealTable="tbl_Users",             KeyColumn="UserID" }
        };

        // ---------- поля ----------
        private string login;
        private string roleKey;      // administrator / methodist / teacher / student
        private string roleDisplay;  // роль для отображения
        private string currentTitle = "";
        private OleDbDataAdapter adapter = null;
        private DataTable table = null;

        private Label lblUser;
        private ComboBox cbTables;
        private Button btnAdd, btnSave, btnDelete, btnRefresh, btnLogout;
        private Button btnEditGrade, btnListByGroup, btnScheduleReport, btnSession;
        private DataGridView grid;

        // фильтры журнала (год, месяц, группа)
        private Panel pnlFilters;
        private ComboBox cbJGroup, cbJYear, cbJMonth;
        private List<int> jYears = new List<int>();
        private bool _loadingFilters = false;

        // ---------- конструктор ----------
        public Form1(string login, string role)
        {
            this.login = login == null ? "" : login;
            string r = (role == null ? "" : role).Trim().ToLower();
            // Роли в БД (tbl_Users.Role) хранятся по-русски: нормализуем к внутренним ключам
            if (r == "администратор" || r == "admin") r = "administrator";
            if (r == "методист" || r == "деканат") r = "methodist";
            if (r == "преподаватель") r = "teacher";
            if (r == "студент") r = "student";
            if (r != "administrator" && r != "methodist" && r != "teacher" && r != "student")
                r = "student";
            roleKey = r;
            roleDisplay = RoleDisplay();
            EnsureJournalTable();
            BuildUi();
            ApplyRolePermissions();
        }

        // Конструктор без параметров - ТОЛЬКО для дизайнера Visual Studio,
        // чтобы Design-режим не выдавал ошибку. Ничего не строит и к БД
        // не обращается. Реальный запуск формы: new Form1(login, role).
        public Form1()
        {
            InitializeComponent();
        }

        private string RoleDisplay()
        {
            switch (roleKey)
            {
                case "administrator": return "Администратор";
                case "methodist": return "Методист";
                case "teacher": return "Преподаватель";
                default: return "Студент";
            }
        }

        // Автоматическое создание таблицы журнала в БД (при первом запуске)
        private void EnsureJournalTable()
        {
            try
            {
                using (OleDbConnection con = new OleDbConnection(Db.ConnStr))
                {
                    con.Open();
                    bool exists;
                    try
                    {
                        using (OleDbCommand cmd = new OleDbCommand("SELECT COUNT(*) FROM tbl_Journal", con))
                            Convert.ToInt32(cmd.ExecuteScalar());
                        exists = true;
                    }
                    catch { exists = false; }
                    if (!exists)
                    {
                        using (OleDbCommand cmd = new OleDbCommand(
                            "CREATE TABLE tbl_Journal (" +
                            "RecordID COUNTER PRIMARY KEY, " +
                            "StudentID LONG, " +
                            "GroupID TEXT(50), " +
                            "DisciplineID LONG, " +
                            "TeacherID LONG, " +
                            "GradeDate DATETIME, " +
                            "Grade LONG)", con))
                            cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось создать таблицу журнала (tbl_Journal):\n" + ex.Message,
                    "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // ---------- построение интерфейса ----------
        private void BuildUi()
        {
            Text = "ИС Деканат (Вариант 7) - " + login + " (" + roleDisplay + ")";
            ClientSize = new Size(1020, 660);
            StartPosition = FormStartPosition.CenterScreen;
            Font = new Font("Segoe UI", 9F);

            lblUser = new Label();
            lblUser.Location = new Point(12, 12);
            lblUser.AutoSize = true;
            lblUser.Text = "Вы вошли как: " + login + " (" + roleDisplay + ")";
            lblUser.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            Controls.Add(lblUser);

            btnLogout = new Button();
            btnLogout.Text = "Сменить пользователя";
            btnLogout.Location = new Point(854, 9);
            btnLogout.Size = new Size(154, 28);
            btnLogout.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnLogout.Click += delegate { Close(); };
            Controls.Add(btnLogout);

            Label lblTable = new Label();
            lblTable.Location = new Point(12, 55);
            lblTable.AutoSize = true;
            lblTable.Text = "Таблица:";
            Controls.Add(lblTable);

            cbTables = new ComboBox();
            cbTables.Location = new Point(70, 52);
            cbTables.Size = new Size(250, 24);
            cbTables.DropDownStyle = ComboBoxStyle.DropDownList;
            cbTables.SelectedIndexChanged += delegate
            {
                currentTitle = Convert.ToString(cbTables.SelectedItem);
                LoadTable();
            };
            Controls.Add(cbTables);

            btnAdd = new Button();
            btnAdd.Text = "Добавить...";
            btnAdd.Location = new Point(330, 50);
            btnAdd.Size = new Size(150, 30);
            btnAdd.Click += BtnAdd_Click;
            Controls.Add(btnAdd);

            btnSave = new Button();
            btnSave.Text = "Сохранить изменения";
            btnSave.Location = new Point(488, 50);
            btnSave.Size = new Size(150, 30);
            btnSave.Click += BtnSave_Click;
            Controls.Add(btnSave);

            btnDelete = new Button();
            btnDelete.Text = "Удалить";
            btnDelete.Location = new Point(646, 50);
            btnDelete.Size = new Size(130, 30);
            btnDelete.Click += BtnDelete_Click;
            Controls.Add(btnDelete);

            btnRefresh = new Button();
            btnRefresh.Text = "Обновить";
            btnRefresh.Location = new Point(784, 50);
            btnRefresh.Size = new Size(110, 30);
            btnRefresh.Click += delegate { LoadTable(); };
            Controls.Add(btnRefresh);

            // операции из диаграмм
            btnEditGrade = new Button();
            btnEditGrade.Text = "Изменить оценку";
            btnEditGrade.Location = new Point(12, 88);
            btnEditGrade.Size = new Size(170, 30);
            btnEditGrade.Click += BtnEditGrade_Click;
            Controls.Add(btnEditGrade);

            btnListByGroup = new Button();
            btnListByGroup.Text = "Списки студентов по группам";
            btnListByGroup.Location = new Point(190, 88);
            btnListByGroup.Size = new Size(220, 30);
            btnListByGroup.Click += delegate
            {
                using (FormListByGroup f = new FormListByGroup()) f.ShowDialog(this);
            };
            Controls.Add(btnListByGroup);

            btnScheduleReport = new Button();
            btnScheduleReport.Text = "Расписание группы";
            btnScheduleReport.Location = new Point(418, 88);
            btnScheduleReport.Size = new Size(180, 30);
            btnScheduleReport.Click += delegate
            {
                using (FormScheduleReport f = new FormScheduleReport()) f.ShowDialog(this);
            };
            Controls.Add(btnScheduleReport);

            btnSession = new Button();
            btnSession.Text = "Длительность сессии";
            btnSession.Location = new Point(606, 88);
            btnSession.Size = new Size(170, 30);
            btnSession.Click += delegate
            {
                using (FormSessionDuration f = new FormSessionDuration()) f.ShowDialog(this);
            };
            Controls.Add(btnSession);

            // фильтры журнала: группа, год, месяц (из диаграммы состояний)
            pnlFilters = new Panel();
            pnlFilters.Location = new Point(12, 124);
            pnlFilters.Size = new Size(996, 34);
            pnlFilters.Visible = false;
            Controls.Add(pnlFilters);

            Label lblJG = new Label();
            lblJG.Location = new Point(0, 6);
            lblJG.AutoSize = true;
            lblJG.Text = "Группа:";
            pnlFilters.Controls.Add(lblJG);

            cbJGroup = new ComboBox();
            cbJGroup.Location = new Point(63, 3);
            cbJGroup.Width = 140;
            cbJGroup.DropDownStyle = ComboBoxStyle.DropDownList;
            pnlFilters.Controls.Add(cbJGroup);

            Label lblJY = new Label();
            lblJY.Location = new Point(218, 6);
            lblJY.AutoSize = true;
            lblJY.Text = "Год:";
            pnlFilters.Controls.Add(lblJY);

            cbJYear = new ComboBox();
            cbJYear.Location = new Point(253, 3);
            cbJYear.Width = 80;
            cbJYear.DropDownStyle = ComboBoxStyle.DropDownList;
            pnlFilters.Controls.Add(cbJYear);

            Label lblJM = new Label();
            lblJM.Location = new Point(348, 6);
            lblJM.AutoSize = true;
            lblJM.Text = "Месяц:";
            pnlFilters.Controls.Add(lblJM);

            cbJMonth = new ComboBox();
            cbJMonth.Location = new Point(398, 3);
            cbJMonth.Width = 130;
            cbJMonth.DropDownStyle = ComboBoxStyle.DropDownList;
            pnlFilters.Controls.Add(cbJMonth);

            Label lblJInfo = new Label();
            lblJInfo.Location = new Point(545, 6);
            lblJInfo.AutoSize = true;
            lblJInfo.ForeColor = Color.Gray;
            lblJInfo.Text = "Просмотр журнала: выберите год, месяц и группу";
            pnlFilters.Controls.Add(lblJInfo);

            EventHandler jFilter = delegate
            {
                if (_loadingFilters) return;
                if (IsJournal) LoadTable();
            };
            cbJGroup.SelectedIndexChanged += jFilter;
            cbJYear.SelectedIndexChanged += jFilter;
            cbJMonth.SelectedIndexChanged += jFilter;

            grid = Ui.MkGrid(12, 126, 996, 522);
            Controls.Add(grid);
        }

        // ---------- права доступа ----------
        private string[] TitlesForRole()
        {
            switch (roleKey)
            {
                case "administrator":
                    return new string[] { "Категории", "Дисциплины", "Группы", "Преподаватели", "Студенты", "Расписание", "Журнал", "Пользователи" };
                case "methodist":
                    return new string[] { "Категории", "Дисциплины", "Группы", "Преподаватели", "Студенты", "Расписание", "Журнал" };
                case "teacher":
                    return new string[] { "Дисциплины", "Группы", "Преподаватели", "Студенты", "Расписание", "Журнал" };
                default:
                    return new string[] { "Группы", "Расписание", "Журнал" };
            }
        }

        private TableInfo CurrentTable
        {
            get { return Tables.FirstOrDefault(t => t.Title == currentTitle); }
        }

        private bool IsJournal { get { return currentTitle == "Журнал"; } }

        // редактирование обычных таблиц
        private bool CanEditTable(TableInfo ti)
        {
            if (ti == null) return false;
            if (ti.ReadOnlyView) return false;
            if (roleKey == "administrator") return true;
            if (roleKey == "methodist") return ti.Title != "Пользователи";
            return false;
        }

        // поставить оценку / изменить оценку - преподаватель, методист и администратор
        private bool CanAddGrades()
        {
            return roleKey == "teacher" || roleKey == "administrator" || roleKey == "methodist";
        }

        // изменение журнала (удаление записей) - преподаватель, методист и администратор
        private bool CanDeleteGrades()
        {
            return roleKey == "teacher" || roleKey == "administrator" || roleKey == "methodist";
        }

        private static void Deny()
        {
            MessageBox.Show("У вас нет прав на выполнение этой операции!", "Доступ запрещён",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private void ApplyRolePermissions()
        {
            cbTables.Items.Clear();
            foreach (string t in TitlesForRole()) cbTables.Items.Add(t);
            int idx = cbTables.Items.IndexOf("Расписание");
            if (idx < 0) idx = 0;
            if (cbTables.Items.Count > 0) cbTables.SelectedIndex = idx;
            // списки студентов по группам - методист и администратор
            btnListByGroup.Visible = (roleKey == "methodist" || roleKey == "administrator");
            UpdateButtons();
        }

        private void UpdateButtons()
        {
            TableInfo ti = CurrentTable;
            bool journal = IsJournal;
            bool editable = CanEditTable(ti);
            btnSave.Visible = editable;
            btnAdd.Visible = journal ? CanAddGrades() : editable;
            btnAdd.Text = journal ? "Поставить оценку..." : "Добавить...";
            btnDelete.Visible = journal ? CanDeleteGrades() : editable;
            btnEditGrade.Visible = journal && CanAddGrades();
        }

        // ---------- фильтры журнала ----------
        private void LoadJournalFilters()
        {
            _loadingFilters = true;
            try
            {
                string keepGroup = Convert.ToString(cbJGroup.SelectedItem);
                int keepYearIdx = cbJYear.SelectedIndex;
                int keepMonthIdx = cbJMonth.SelectedIndex;

                cbJGroup.Items.Clear();
                cbJGroup.Items.Add("Все группы");
                try
                {
                    using (OleDbConnection con = new OleDbConnection(Db.ConnStr))
                    {
                        con.Open();
                        using (OleDbCommand cmd = new OleDbCommand("SELECT GroupID FROM tbl_Groups ORDER BY GroupID", con))
                        using (OleDbDataReader rd = cmd.ExecuteReader())
                            while (rd.Read()) cbJGroup.Items.Add(Convert.ToString(rd[0]));
                    }
                }
                catch { }
                int gi = cbJGroup.Items.IndexOf(keepGroup);
                cbJGroup.SelectedIndex = gi >= 0 ? gi : 0;

                cbJYear.Items.Clear();
                cbJYear.Items.Add("Все годы");
                List<int> years = new List<int>();
                try
                {
                    using (OleDbConnection con = new OleDbConnection(Db.ConnStr))
                    {
                        con.Open();
                        using (OleDbCommand cmd = new OleDbCommand(
                            "SELECT GradeDate FROM tbl_Journal WHERE GradeDate IS NOT NULL", con))
                        using (OleDbDataReader rd = cmd.ExecuteReader())
                            while (rd.Read())
                            {
                                int y = Convert.ToDateTime(rd[0]).Year;
                                if (!years.Contains(y)) years.Add(y);
                            }
                    }
                }
                catch { }
                jYears = years.OrderByDescending(v => v).ToList();
                foreach (int y in jYears) cbJYear.Items.Add(y);
                cbJYear.SelectedIndex = (keepYearIdx >= 0 && keepYearIdx < cbJYear.Items.Count) ? keepYearIdx : 0;

                cbJMonth.Items.Clear();
                cbJMonth.Items.Add("Все месяцы");
                foreach (string m in new string[] { "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
                                                    "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь" })
                    cbJMonth.Items.Add(m);
                cbJMonth.SelectedIndex = (keepMonthIdx >= 0 && keepMonthIdx < cbJMonth.Items.Count) ? keepMonthIdx : 0;
            }
            finally { _loadingFilters = false; }
        }

        private string BuildJournalSql(List<OleDbParameter> prms)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(JournalBaseSql);
            List<string> cond = new List<string>();
            if (cbJGroup.SelectedIndex > 0)
            {
                cond.Add("j.GroupID=?");
                prms.Add(new OleDbParameter("?", Convert.ToString(cbJGroup.SelectedItem)));
            }
            if (cbJYear.SelectedIndex > 0 && cbJYear.SelectedIndex - 1 < jYears.Count)
            {
                cond.Add("YEAR(j.GradeDate)=?");
                prms.Add(new OleDbParameter("?", jYears[cbJYear.SelectedIndex - 1]));
            }
            if (cbJMonth.SelectedIndex > 0)
            {
                cond.Add("MONTH(j.GradeDate)=?");
                prms.Add(new OleDbParameter("?", cbJMonth.SelectedIndex));
            }
            if (cond.Count > 0) sb.Append(" WHERE ").Append(string.Join(" AND ", cond.ToArray()));
            sb.Append(" ORDER BY j.GradeDate, s.LastName");
            return sb.ToString();
        }

        // ---------- загрузка таблицы ----------
        private void LoadTable()
        {
            TableInfo ti = CurrentTable;
            if (ti == null) { grid.DataSource = null; return; }

            bool journal = IsJournal;
            pnlFilters.Visible = journal;
            if (journal)
            {
                LoadJournalFilters();
                grid.Location = new Point(12, 166);
                grid.Size = new Size(996, 482);
            }
            else
            {
                grid.Location = new Point(12, 126);
                grid.Size = new Size(996, 522);
            }

            try
            {
                table = new DataTable();
                if (ti.ReadOnlyView)
                {
                    adapter = null;
                    List<OleDbParameter> prms = new List<OleDbParameter>();
                    string sql = journal ? BuildJournalSql(prms) : ti.SelectSql;
                    using (OleDbDataAdapter da = new OleDbDataAdapter(sql, Db.ConnStr))
                    {
                        foreach (OleDbParameter p in prms) da.SelectCommand.Parameters.Add(p);
                        da.Fill(table);
                    }
                    grid.ReadOnly = true;
                }
                else
                {
                    adapter = new OleDbDataAdapter(ti.SelectSql, Db.ConnStr);
                    OleDbCommandBuilder builder = new OleDbCommandBuilder(adapter);
                    builder.QuotePrefix = "[";
                    builder.QuoteSuffix = "]";
                    adapter.Fill(table);
                    grid.ReadOnly = !CanEditTable(ti);
                }
                grid.DataSource = table;
                StyleDateColumns();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных:\n" + ex.Message, "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            UpdateButtons();
        }

        private void StyleDateColumns()
        {
            foreach (DataGridViewColumn c in grid.Columns)
                if (c.ValueType == typeof(DateTime))
                    c.DefaultCellStyle.Format = "dd.MM.yyyy";
        }

        // ---------- обработчики кнопок ----------
        private void BtnAdd_Click(object sender, EventArgs e)
        {
            TableInfo ti = CurrentTable;
            if (ti == null) return;
            if (IsJournal)
            {
                if (!CanAddGrades()) { Deny(); return; }
                using (FormAddGrade f = new FormAddGrade())
                    if (f.ShowDialog(this) == DialogResult.OK) LoadTable();
                return;
            }
            if (!CanEditTable(ti)) { Deny(); return; }
            Form addForm = null;
            switch (ti.Title)
            {
                case "Категории": addForm = new FormAddCategory(); break;
                case "Дисциплины": addForm = new FormAddDiscipline(); break;
                case "Группы": addForm = new FormAddGroup(); break;
                case "Преподаватели": addForm = new FormAddTeacher(); break;
                case "Студенты": addForm = new FormAddStudent(); break;
                case "Расписание": addForm = new FormAddSchedule(); break;
                case "Пользователи": addForm = new FormAddUser(); break;
            }
            if (addForm == null) return;
            if (addForm.ShowDialog(this) == DialogResult.OK) LoadTable();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            TableInfo ti = CurrentTable;
            if (ti == null || ti.ReadOnlyView) return;
            if (!CanEditTable(ti)) { Deny(); return; }
            grid.EndEdit();
            try
            {
                adapter.Update(table);
                MessageBox.Show("Изменения успешно сохранены.", "Сохранение",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadTable();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка сохранения:\n" + ex.Message, "Сохранение",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                LoadTable();
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            TableInfo ti = CurrentTable;
            if (ti == null) return;
            if (grid.CurrentRow == null)
            {
                MessageBox.Show("Выберите запись для удаления!", "Удаление",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (IsJournal)
            {
                if (!CanDeleteGrades()) { Deny(); return; }
            }
            else
            {
                if (!CanEditTable(ti)) { Deny(); return; }
                if (ti.Title == "Пользователи")
                {
                    string u = Convert.ToString(grid.CurrentRow.Cells["Username"].Value);
                    if (string.Equals(u, login, StringComparison.OrdinalIgnoreCase))
                    {
                        MessageBox.Show("Нельзя удалить собственную учётную запись!", "Удаление",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                }
            }
            DataGridViewRow row = grid.CurrentRow;
            object keyVal = row.Cells[0].Value;
            DialogResult res = MessageBox.Show("Вы уверены, что хотите удалить выбранную запись?",
                "Удаление", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res != DialogResult.Yes) return;
            try
            {
                using (OleDbConnection con = new OleDbConnection(Db.ConnStr))
                {
                    con.Open();
                    using (OleDbCommand cmd = new OleDbCommand(
                        "DELETE FROM " + ti.RealTable + " WHERE " + ti.KeyColumn + "=?", con))
                    {
                        if (ti.TextKey) cmd.Parameters.AddWithValue("?", Convert.ToString(keyVal));
                        else cmd.Parameters.AddWithValue("?", Convert.ToInt32(keyVal));
                        cmd.ExecuteNonQuery();
                    }
                }
                LoadTable();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка удаления:\n" + ex.Message, "Удаление",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnEditGrade_Click(object sender, EventArgs e)
        {
            if (!IsJournal) return;
            if (!CanAddGrades()) { Deny(); return; }
            if (grid.CurrentRow == null)
            {
                MessageBox.Show("Выберите запись в таблице!", "Изменить оценку",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            int recordId = Convert.ToInt32(grid.CurrentRow.Cells[0].Value);
            using (FormEditGrade f = new FormEditGrade(recordId))
                if (f.ShowDialog(this) == DialogResult.OK) LoadTable();
        }

        // ---------- общие помощники ----------
        // Комбобокс с данными из БД; editable=true - можно вводить текст
        // вручную + автозаполнение (для групп)
        public static ComboBox MakeCombo(string sql, string display, string value, bool editable)
        {
            ComboBox cb = new ComboBox();
            DataTable dt = new DataTable();
            using (OleDbDataAdapter da = new OleDbDataAdapter(sql, Db.ConnStr))
                da.Fill(dt);
            cb.DataSource = dt;
            cb.DisplayMember = display;
            cb.ValueMember = value;
            if (editable)
            {
                cb.DropDownStyle = ComboBoxStyle.DropDown;
                cb.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                cb.AutoCompleteSource = AutoCompleteSource.CustomSource;
                AutoCompleteStringCollection src = new AutoCompleteStringCollection();
                foreach (DataRow r in dt.Rows)
                    src.Add(Convert.ToString(r[display]));
                cb.AutoCompleteCustomSource = src;
            }
            else
            {
                cb.DropDownStyle = ComboBoxStyle.DropDownList;
            }
            return cb;
        }

        // Проверка группы: точное совпадение -> без учёта регистра ->
        // предложение создать группу "на лету"
        public static string ResolveGroup(ComboBox cb, IWin32Window owner)
        {
            string txt = cb.Text.Trim();
            if (txt.Length == 0)
            {
                MessageBox.Show(owner, "Выберите или введите группу (например, АЛ-17а)!", "Группа",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return null;
            }
            List<string> ids = new List<string>();
            using (OleDbConnection con = new OleDbConnection(Db.ConnStr))
            {
                con.Open();
                using (OleDbCommand cmd = new OleDbCommand("SELECT GroupID FROM tbl_Groups", con))
                using (OleDbDataReader rd = cmd.ExecuteReader())
                    while (rd.Read()) ids.Add(Convert.ToString(rd[0]));
            }
            foreach (string g in ids)
                if (g == txt) { cb.Text = g; return g; }
            foreach (string g in ids)
                if (string.Equals(g, txt, StringComparison.OrdinalIgnoreCase)) { cb.Text = g; return g; }
            DialogResult res = MessageBox.Show(owner,
                "Группа \"" + txt + "\" не найдена в базе данных.\nСоздать её сейчас?",
                "Группа", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res == DialogResult.Yes)
            {
                using (FormAddGroup f = new FormAddGroup(txt))
                {
                    if (f.ShowDialog(owner) == DialogResult.OK && !string.IsNullOrEmpty(f.CreatedGroupId))
                    {
                        cb.Text = f.CreatedGroupId;
                        return f.CreatedGroupId;
                    }
                }
            }
            return null;
        }
    }

    // ================================================================
    //  Формы добавления записей
    // ================================================================

    // Новая категория дисциплин
    public class FormAddCategory : Form
    {
        private TextBox txtName;

        public FormAddCategory()
        {
            Ui.Dialog(this, "Новая категория", 400, 110);
            Controls.Add(Ui.MkLabel("Название категории:", 14));
            txtName = Ui.MkTextBox(150, 12, 230);
            Controls.Add(txtName);
            Ui.Buttons(this, BtnOk_Click);
        }

        private void BtnOk_Click(object sender, EventArgs e)
        {
            string name = txtName.Text.Trim();
            if (name.Length == 0) { Ui.Warn("Введите название категории!", Text); return; }
            try
            {
                using (OleDbConnection con = new OleDbConnection(Db.ConnStr))
                {
                    con.Open();
                    object cnt;
                    using (OleDbCommand cmd = new OleDbCommand(
                        "SELECT COUNT(*) FROM tbl_Categories WHERE LCase(CategoryName)=?", con))
                    {
                        cmd.Parameters.AddWithValue("?", name.ToLower());
                        cnt = cmd.ExecuteScalar();
                    }
                    if (Convert.ToInt32(cnt) > 0)
                    {
                        Ui.Warn("Категория \"" + name + "\" уже существует!", Text);
                        return;
                    }
                    using (OleDbCommand cmd = new OleDbCommand(
                        "INSERT INTO tbl_Categories (CategoryName) VALUES (?)", con))
                    {
                        cmd.Parameters.AddWithValue("?", name);
                        cmd.ExecuteNonQuery();
                    }
                }
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex) { Ui.Error(ex); }
        }
    }

    // Новый преподаватель
    public class FormAddTeacher : Form
    {
        private TextBox txtFio, txtDep;

        public FormAddTeacher()
        {
            Ui.Dialog(this, "Новый преподаватель", 400, 143);
            Controls.Add(Ui.MkLabel("ФИО:", 14));
            txtFio = Ui.MkTextBox(150, 12, 230);
            Controls.Add(txtFio);
            Controls.Add(Ui.MkLabel("Кафедра:", 47));
            txtDep = Ui.MkTextBox(150, 45, 230);
            Controls.Add(txtDep);
            Ui.Buttons(this, BtnOk_Click);
        }

        private void BtnOk_Click(object sender, EventArgs e)
        {
            string fio = txtFio.Text.Trim();
            if (fio.Length == 0) { Ui.Warn("Введите ФИО преподавателя!", Text); return; }
            try
            {
                using (OleDbConnection con = new OleDbConnection(Db.ConnStr))
                {
                    con.Open();
                    using (OleDbCommand cmd = new OleDbCommand(
                        "INSERT INTO tbl_Teacher (TeacherFIO, Department) VALUES (?,?)", con))
                    {
                        cmd.Parameters.AddWithValue("?", fio);
                        cmd.Parameters.AddWithValue("?", txtDep.Text.Trim());
                        cmd.ExecuteNonQuery();
                    }
                }
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex) { Ui.Error(ex); }
        }
    }

    // Новая группа (с возможностью предзаполнения шифра)
    public class FormAddGroup : Form
    {
        public string CreatedGroupId = null;
        private TextBox txtId, txtSpec;
        private ComboBox cbCourse;

        public FormAddGroup() : this(null) { }

        public FormAddGroup(string presetId)
        {
            Ui.Dialog(this, "Новая группа", 400, 176);
            Controls.Add(Ui.MkLabel("Шифр группы:", 14));
            txtId = Ui.MkTextBox(150, 12, 230);
            txtId.Text = presetId == null ? "" : presetId;
            Controls.Add(txtId);

            Controls.Add(Ui.MkLabel("Курс:", 47));
            cbCourse = new ComboBox();
            cbCourse.Location = new Point(150, 45);
            cbCourse.Width = 230;
            cbCourse.DropDownStyle = ComboBoxStyle.DropDownList;
            for (int i = 1; i <= 6; i++) cbCourse.Items.Add(i);
            cbCourse.SelectedIndex = 0;
            Controls.Add(cbCourse);

            Controls.Add(Ui.MkLabel("Специальность:", 80));
            txtSpec = Ui.MkTextBox(150, 78, 230);
            Controls.Add(txtSpec);

            Ui.Buttons(this, BtnOk_Click);
        }

        private void BtnOk_Click(object sender, EventArgs e)
        {
            string id = txtId.Text.Trim();
            if (id.Length == 0) { Ui.Warn("Введите шифр группы!", Text); return; }
            try
            {
                using (OleDbConnection con = new OleDbConnection(Db.ConnStr))
                {
                    con.Open();
                    object cnt;
                    using (OleDbCommand cmd = new OleDbCommand(
                        "SELECT COUNT(*) FROM tbl_Groups WHERE LCase(GroupID)=?", con))
                    {
                        cmd.Parameters.AddWithValue("?", id.ToLower());
                        cnt = cmd.ExecuteScalar();
                    }
                    if (Convert.ToInt32(cnt) > 0)
                    {
                        Ui.Warn("Группа \"" + id + "\" уже существует!", Text);
                        return;
                    }
                    using (OleDbCommand cmd = new OleDbCommand(
                        "INSERT INTO tbl_Groups (GroupID, Course, Specialty) VALUES (?,?,?)", con))
                    {
                        cmd.Parameters.AddWithValue("?", id);
                        cmd.Parameters.AddWithValue("?", cbCourse.SelectedItem);
                        cmd.Parameters.AddWithValue("?", txtSpec.Text.Trim());
                        cmd.ExecuteNonQuery();
                    }
                }
                CreatedGroupId = id;
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex) { Ui.Error(ex); }
        }
    }

    // Новый студент (группа: выбор из списка + ручной ввод + автосоздание)
    public class FormAddStudent : Form
    {
        private TextBox txtLast, txtFirst;
        private ComboBox cbGroup;

        public FormAddStudent()
        {
            Ui.Dialog(this, "Новый студент", 400, 176);
            Controls.Add(Ui.MkLabel("Фамилия:", 14));
            txtLast = Ui.MkTextBox(150, 12, 230);
            Controls.Add(txtLast);

            Controls.Add(Ui.MkLabel("Имя:", 47));
            txtFirst = Ui.MkTextBox(150, 45, 230);
            Controls.Add(txtFirst);

            Controls.Add(Ui.MkLabel("Группа:", 80));
            cbGroup = Form1.MakeCombo(
                "SELECT GroupID, GroupID AS GVal FROM tbl_Groups ORDER BY GroupID",
                "GroupID", "GVal", true);
            cbGroup.Location = new Point(150, 78);
            cbGroup.Width = 230;
            Controls.Add(cbGroup);

            Ui.Buttons(this, BtnOk_Click);
        }

        private void BtnOk_Click(object sender, EventArgs e)
        {
            string last = txtLast.Text.Trim();
            string first = txtFirst.Text.Trim();
            if (last.Length == 0) { Ui.Warn("Введите фамилию!", Text); return; }
            if (first.Length == 0) { Ui.Warn("Введите имя!", Text); return; }
            string grp = Form1.ResolveGroup(cbGroup, this);
            if (grp == null) return;
            try
            {
                using (OleDbConnection con = new OleDbConnection(Db.ConnStr))
                {
                    con.Open();
                    using (OleDbCommand cmd = new OleDbCommand(
                        "INSERT INTO tbl_Students (LastName, FirstName, GroupID) VALUES (?,?,?)", con))
                    {
                        cmd.Parameters.AddWithValue("?", last);
                        cmd.Parameters.AddWithValue("?", first);
                        cmd.Parameters.AddWithValue("?", grp);
                        cmd.ExecuteNonQuery();
                    }
                }
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex) { Ui.Error(ex); }
        }
    }

    // Новая дисциплина
    public class FormAddDiscipline : Form
    {
        private TextBox txtName, txtHours;
        private ComboBox cbCat;

        public FormAddDiscipline()
        {
            Ui.Dialog(this, "Новая дисциплина", 400, 176);
            Controls.Add(Ui.MkLabel("Название:", 14));
            txtName = Ui.MkTextBox(150, 12, 230);
            Controls.Add(txtName);

            Controls.Add(Ui.MkLabel("Категория:", 47));
            cbCat = Form1.MakeCombo(
                "SELECT CategoryID, CategoryName FROM tbl_Categories ORDER BY CategoryName",
                "CategoryName", "CategoryID", false);
            cbCat.Location = new Point(150, 45);
            cbCat.Width = 230;
            Controls.Add(cbCat);

            Controls.Add(Ui.MkLabel("Всего часов:", 80));
            txtHours = Ui.MkTextBox(150, 78, 230);
            Controls.Add(txtHours);

            Ui.Buttons(this, BtnOk_Click);
        }

        private void BtnOk_Click(object sender, EventArgs e)
        {
            string name = txtName.Text.Trim();
            if (name.Length == 0) { Ui.Warn("Введите название дисциплины!", Text); return; }
            int hours;
            if (!int.TryParse(txtHours.Text.Trim(), out hours) || hours <= 0)
            {
                Ui.Warn("Всего часов - целое положительное число!", Text);
                return;
            }
            try
            {
                using (OleDbConnection con = new OleDbConnection(Db.ConnStr))
                {
                    con.Open();
                    object cnt;
                    using (OleDbCommand cmd = new OleDbCommand(
                        "SELECT COUNT(*) FROM tbl_Discipline WHERE LCase(DisciplineName)=?", con))
                    {
                        cmd.Parameters.AddWithValue("?", name.ToLower());
                        cnt = cmd.ExecuteScalar();
                    }
                    if (Convert.ToInt32(cnt) > 0)
                    {
                        Ui.Warn("Дисциплина \"" + name + "\" уже существует!", Text);
                        return;
                    }
                    using (OleDbCommand cmd = new OleDbCommand(
                        "INSERT INTO tbl_Discipline (DisciplineName, CategoryID, TotalHours) VALUES (?,?,?)", con))
                    {
                        cmd.Parameters.AddWithValue("?", name);
                        cmd.Parameters.AddWithValue("?",
                            cbCat.SelectedValue == null ? (object)DBNull.Value : cbCat.SelectedValue);
                        cmd.Parameters.AddWithValue("?", hours);
                        cmd.ExecuteNonQuery();
                    }
                }
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex) { Ui.Error(ex); }
        }
    }

    // Новая запись расписания (назначить дату экзамена или зачёта)
    // С проверкой дубля и правилом "два экзамена в один день"
    public class FormAddSchedule : Form
    {
        private ComboBox cbGroup, cbDisc, cbTeach, cbControl;
        private DateTimePicker dtp;
        private Label lblHours;

        public FormAddSchedule()
        {
            Ui.Dialog(this, "Новая запись расписания", 400, 290);

            Controls.Add(Ui.MkLabel("Группа:", 15));
            cbGroup = Form1.MakeCombo(
                "SELECT GroupID, GroupID AS GVal FROM tbl_Groups ORDER BY GroupID",
                "GroupID", "GVal", true);
            cbGroup.Location = new Point(150, 12);
            cbGroup.Width = 230;
            Controls.Add(cbGroup);

            Controls.Add(Ui.MkLabel("Дисциплина:", 48));
            cbDisc = Form1.MakeCombo(
                "SELECT DisciplineID, DisciplineName FROM tbl_Discipline ORDER BY DisciplineName",
                "DisciplineName", "DisciplineID", false);
            cbDisc.Location = new Point(150, 45);
            cbDisc.Width = 230;
            Controls.Add(cbDisc);
            cbDisc.SelectedIndexChanged += delegate { UpdateHours(); };

            Controls.Add(Ui.MkLabel("Преподаватель:", 81));
            cbTeach = Form1.MakeCombo(
                "SELECT TeacherID, TeacherFIO FROM tbl_Teacher ORDER BY TeacherFIO",
                "TeacherFIO", "TeacherID", false);
            cbTeach.Location = new Point(150, 78);
            cbTeach.Width = 230;
            Controls.Add(cbTeach);

            Controls.Add(Ui.MkLabel("Вид контроля:", 114));
            cbControl = new ComboBox();
            cbControl.Location = new Point(150, 111);
            cbControl.Width = 230;
            cbControl.DropDownStyle = ComboBoxStyle.DropDown;
            cbControl.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            cbControl.AutoCompleteSource = AutoCompleteSource.CustomSource;
            List<string> vals = new List<string>();
            try
            {
                DataTable dt = new DataTable();
                using (OleDbDataAdapter da = new OleDbDataAdapter(
                    "SELECT DISTINCT ControlType FROM tbl_SessionsSchedule " +
                    "WHERE ControlType IS NOT NULL ORDER BY ControlType", Db.ConnStr))
                    da.Fill(dt);
                foreach (DataRow r in dt.Rows) vals.Add(Convert.ToString(r[0]));
            }
            catch { }
            foreach (string s in new string[] { "Экзамен", "Зачёт" })
                if (!vals.Contains(s)) vals.Add(s);
            AutoCompleteStringCollection src = new AutoCompleteStringCollection();
            src.AddRange(vals.ToArray());
            cbControl.AutoCompleteCustomSource = src;
            cbControl.Items.AddRange(vals.ToArray());
            Controls.Add(cbControl);

            Controls.Add(Ui.MkLabel("Дата мероприятия:", 147));
            dtp = new DateTimePicker();
            dtp.Location = new Point(150, 144);
            dtp.Width = 230;
            dtp.Format = DateTimePickerFormat.Short;
            dtp.Value = DateTime.Today;
            Controls.Add(dtp);

            // расчёт часов дисциплии (из диаграммы последовательности)
            lblHours = new Label();
            lblHours.Location = new Point(12, 180);
            lblHours.AutoSize = true;
            lblHours.ForeColor = Color.Gray;
            lblHours.Text = "Всего часов по дисциплине: -";
            Controls.Add(lblHours);

            Ui.Buttons(this, BtnOk_Click);
            UpdateHours();
        }

        private void UpdateHours()
        {
            try
            {
                if (cbDisc.SelectedIndex < 0)
                {
                    lblHours.Text = "Всего часов по дисциплине: -";
                    return;
                }
                using (OleDbConnection con = new OleDbConnection(Db.ConnStr))
                {
                    con.Open();
                    using (OleDbCommand cmd = new OleDbCommand(
                        "SELECT TotalHours FROM tbl_Discipline WHERE DisciplineID=?", con))
                    {
                        cmd.Parameters.AddWithValue("?", cbDisc.SelectedValue);
                        object o = cmd.ExecuteScalar();
                        lblHours.Text = "Всего часов по дисциплине: " +
                            (o == null || o == DBNull.Value ? "-" : Convert.ToString(o));
                    }
                }
            }
            catch { lblHours.Text = "Всего часов по дисциплине: -"; }
        }

        private void BtnOk_Click(object sender, EventArgs e)
        {
            string grp = Form1.ResolveGroup(cbGroup, this);
            if (grp == null) return;
            if (cbDisc.SelectedIndex < 0) { Ui.Warn("Выберите дисциплину!", Text); return; }
            if (cbTeach.SelectedIndex < 0) { Ui.Warn("Выберите преподавателя!", Text); return; }
            string ctrl = cbControl.Text.Trim();
            if (ctrl.Length == 0) { Ui.Warn("Введите вид контроля (Экзамен/Зачёт)!", Text); return; }
            DateTime d = dtp.Value.Date;
            if (!ValidationModule.ValidDate(d)) { Ui.Warn("Дата вне допустимого диапазона!", Text); return; }
            try
            {
                using (OleDbConnection con = new OleDbConnection(Db.ConnStr))
                {
                    con.Open();
                    int discId = Convert.ToInt32(cbDisc.SelectedValue);
                    int teachId = Convert.ToInt32(cbTeach.SelectedValue);

                    // проверка дубликата: группа + дисциплина + дата
                    using (OleDbCommand cmd = new OleDbCommand(
                        "SELECT COUNT(*) FROM tbl_SessionsSchedule " +
                        "WHERE GroupID=? AND DisciplineID=? AND ExamDate=?", con))
                    {
                        cmd.Parameters.AddWithValue("?", grp);
                        cmd.Parameters.AddWithValue("?", discId);
                        cmd.Parameters.AddWithValue("?", d);
                        if (Convert.ToInt32(cmd.ExecuteScalar()) > 0)
                        {
                            Ui.Warn("Запись для этой группы, дисциплины и даты уже существует!", Text);
                            return;
                        }
                    }

                    // правило "два экзамена в один день"
                    if (ctrl.ToLower().Contains("экзам") &&
                        ValidationModule.HasExamOnDate(con, grp, d))
                    {
                        MessageBox.Show(this,
                            "У этой группы уже есть экзамен на выбранную дату!\n" +
                            "(правило: два экзамена в один день запрещены)",
                            Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    using (OleDbCommand cmd = new OleDbCommand(
                        "INSERT INTO tbl_SessionsSchedule " +
                        "(GroupID, DisciplineID, TeacherID, ControlType, ExamDate) VALUES (?,?,?,?,?)", con))
                    {
                        cmd.Parameters.AddWithValue("?", grp);
                        cmd.Parameters.AddWithValue("?", discId);
                        cmd.Parameters.AddWithValue("?", teachId);
                        cmd.Parameters.AddWithValue("?", ctrl);
                        cmd.Parameters.AddWithValue("?", d);
                        cmd.ExecuteNonQuery();
                    }
                }
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex) { Ui.Error(ex); }
        }
    }

    // Новый пользователь (только для администратора)
    public class FormAddUser : Form
    {
        private TextBox txtLogin, txtPass;
        private ComboBox cbRole;

        public FormAddUser()
        {
            Ui.Dialog(this, "Новый пользователь", 400, 176);
            Controls.Add(Ui.MkLabel("Логин:", 14));
            txtLogin = Ui.MkTextBox(150, 12, 230);
            Controls.Add(txtLogin);

            Controls.Add(Ui.MkLabel("Пароль:", 47));
            txtPass = Ui.MkTextBox(150, 45, 230);
            txtPass.UseSystemPasswordChar = true;
            Controls.Add(txtPass);

            Controls.Add(Ui.MkLabel("Роль:", 80));
            cbRole = new ComboBox();
            cbRole.Location = new Point(150, 78);
            cbRole.Width = 230;
            cbRole.DropDownStyle = ComboBoxStyle.DropDownList;
            cbRole.Items.AddRange(new string[] { "Методист", "Преподаватель", "Студент", "Администратор" });
            cbRole.SelectedIndex = 0;
            Controls.Add(cbRole);

            Ui.Buttons(this, BtnOk_Click);
        }

        private void BtnOk_Click(object sender, EventArgs e)
        {
            string l = txtLogin.Text.Trim();
            string p = txtPass.Text;
            if (l.Length == 0) { Ui.Warn("Введите логин!", Text); return; }
            if (p.Length == 0) { Ui.Warn("Введите пароль!", Text); return; }
            try
            {
                using (OleDbConnection con = new OleDbConnection(Db.ConnStr))
                {
                    con.Open();
                    object cnt;
                    using (OleDbCommand cmd = new OleDbCommand(
                        "SELECT COUNT(*) FROM tbl_Users WHERE LCase(Username)=?", con))
                    {
                        cmd.Parameters.AddWithValue("?", l.ToLower());
                        cnt = cmd.ExecuteScalar();
                    }
                    if (Convert.ToInt32(cnt) > 0)
                    {
                        Ui.Warn("Логин \"" + l + "\" уже занят!", Text);
                        return;
                    }
                    using (OleDbCommand cmd = new OleDbCommand(
                        "INSERT INTO tbl_Users (Username, [Password], Role) VALUES (?,?,?)", con))
                    {
                        cmd.Parameters.AddWithValue("?", l);
                        cmd.Parameters.AddWithValue("?", p);
                        cmd.Parameters.AddWithValue("?", Convert.ToString(cbRole.SelectedItem));
                        cmd.ExecuteNonQuery();
                    }
                }
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex) { Ui.Error(ex); }
        }
    }

    // ================================================================
    //  Поставить оценку (диаграмма последовательности):
    //  группа -> запрос ФИО студента -> проверка студента ->
    //  проверка принадлежности группе -> дата (проверка) ->
    //  оценка (проверка) -> внесение оценки в журнал
    // ================================================================
    public class FormAddGrade : Form
    {
        private ComboBox cbGroup, cbStudent, cbDisc, cbTeach, cbGrade;
        private DateTimePicker dtp;

        public FormAddGrade()
        {
            Ui.Dialog(this, "Поставить оценку", 400, 290);

            Controls.Add(Ui.MkLabel("Группа:", 15));
            cbGroup = Form1.MakeCombo(
                "SELECT GroupID, GroupID AS GVal FROM tbl_Groups ORDER BY GroupID",
                "GroupID", "GVal", true);
            cbGroup.Location = new Point(150, 12);
            cbGroup.Width = 230;
            Controls.Add(cbGroup);

            Controls.Add(Ui.MkLabel("Студент:", 48));
            cbStudent = new ComboBox();
            cbStudent.Location = new Point(150, 45);
            cbStudent.Width = 230;
            cbStudent.DropDownStyle = ComboBoxStyle.DropDownList;
            Controls.Add(cbStudent);

            Controls.Add(Ui.MkLabel("Дисциплина:", 81));
            cbDisc = Form1.MakeCombo(
                "SELECT DisciplineID, DisciplineName FROM tbl_Discipline ORDER BY DisciplineName",
                "DisciplineName", "DisciplineID", false);
            cbDisc.Location = new Point(150, 78);
            cbDisc.Width = 230;
            Controls.Add(cbDisc);

            Controls.Add(Ui.MkLabel("Преподаватель:", 114));
            cbTeach = Form1.MakeCombo(
                "SELECT TeacherID, TeacherFIO FROM tbl_Teacher ORDER BY TeacherFIO",
                "TeacherFIO", "TeacherID", false);
            cbTeach.Location = new Point(150, 111);
            cbTeach.Width = 230;
            Controls.Add(cbTeach);

            Controls.Add(Ui.MkLabel("Дата:", 147));
            dtp = new DateTimePicker();
            dtp.Location = new Point(150, 144);
            dtp.Width = 230;
            dtp.Format = DateTimePickerFormat.Short;
            dtp.Value = DateTime.Today;
            Controls.Add(dtp);

            Controls.Add(Ui.MkLabel("Оценка:", 180));
            cbGrade = Ui.MkGradeCombo(150, 177);
            Controls.Add(cbGrade);

            // при смене группы - обновляем список студентов этой группы
            cbGroup.SelectedIndexChanged += delegate { ReloadStudents(); };
            cbGroup.Leave += delegate { ReloadStudents(); };
            ReloadStudents();

            Ui.Buttons(this, BtnOk_Click);
        }

        // поиск группы по тексту (точное совпадение / без учёта регистра)
        private string FindGroup()
        {
            string txt = cbGroup.Text.Trim();
            if (txt.Length == 0) return null;
            List<string> ids = new List<string>();
            try
            {
                using (OleDbConnection con = new OleDbConnection(Db.ConnStr))
                {
                    con.Open();
                    using (OleDbCommand cmd = new OleDbCommand("SELECT GroupID FROM tbl_Groups", con))
                    using (OleDbDataReader rd = cmd.ExecuteReader())
                        while (rd.Read()) ids.Add(Convert.ToString(rd[0]));
                }
            }
            catch { return null; }
            foreach (string g in ids) if (g == txt) return g;
            foreach (string g in ids)
                if (string.Equals(g, txt, StringComparison.OrdinalIgnoreCase)) return g;
            return null;
        }

        // список студентов выбранной группы (запрос ФИО студентов)
        private void ReloadStudents()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("StudentID", typeof(int));
            dt.Columns.Add("FIO", typeof(string));
            string g = FindGroup();
            if (g != null)
            {
                try
                {
                    DataTable src = new DataTable();
                    using (OleDbDataAdapter da = new OleDbDataAdapter(
                        "SELECT StudentID, LastName & ' ' & FirstName AS FIO FROM tbl_Students " +
                        "WHERE GroupID=? ORDER BY LastName, FirstName", Db.ConnStr))
                    {
                        da.SelectCommand.Parameters.AddWithValue("?", g);
                        da.Fill(src);
                    }
                    foreach (DataRow r in src.Rows)
                        dt.Rows.Add(Convert.ToInt32(r["StudentID"]), Convert.ToString(r["FIO"]));
                }
                catch { }
            }
            cbStudent.DataSource = dt;
            cbStudent.DisplayMember = "FIO";
            cbStudent.ValueMember = "StudentID";
        }

        private void BtnOk_Click(object sender, EventArgs e)
        {
            string grp = Form1.ResolveGroup(cbGroup, this);
            if (grp == null) return;
            if (cbStudent.SelectedIndex < 0)
            {
                Ui.Warn("Выберите студента!\n(если список пуст - в группе нет студентов)", Text);
                return;
            }
            if (cbDisc.SelectedIndex < 0) { Ui.Warn("Выберите дисциплину!", Text); return; }
            if (cbTeach.SelectedIndex < 0) { Ui.Warn("Выберите преподавателя!", Text); return; }
            DateTime d = dtp.Value.Date;
            if (!ValidationModule.ValidDate(d)) { Ui.Warn("Дата вне допустимого диапазона!", Text); return; }
            int grade = Convert.ToInt32(cbGrade.SelectedValue);
            if (!ValidationModule.ValidGrade(grade)) { Ui.Warn("Оценка должна быть от 2 до 5!", Text); return; }

            int studentId = Convert.ToInt32(cbStudent.SelectedValue);
            int discId = Convert.ToInt32(cbDisc.SelectedValue);
            int teachId = Convert.ToInt32(cbTeach.SelectedValue);
            try
            {
                using (OleDbConnection con = new OleDbConnection(Db.ConnStr))
                {
                    con.Open();

                    // проверка принадлежности студента группе
                    if (!ValidationModule.StudentInGroup(con, studentId, grp))
                    {
                        MessageBox.Show(this, "Выбранный студент не состоит в группе " + grp + "!",
                            Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    // проверка: оценка уже была в этот день по этой дисциплине?
                    using (OleDbCommand cmd = new OleDbCommand(
                        "SELECT COUNT(*) FROM tbl_Journal " +
                        "WHERE StudentID=? AND DisciplineID=? AND GradeDate=?", con))
                    {
                        cmd.Parameters.AddWithValue("?", studentId);
                        cmd.Parameters.AddWithValue("?", discId);
                        cmd.Parameters.AddWithValue("?", d);
                        if (Convert.ToInt32(cmd.ExecuteScalar()) > 0)
                        {
                            DialogResult r = MessageBox.Show(this,
                                "Запись для этого студента (дисциплина, дата) уже существует.\n" +
                                "Всё равно добавить ещё одну?",
                                Text, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                            if (r != DialogResult.Yes) return;
                        }
                    }

                    // внесение оценки в журнал
                    using (OleDbCommand cmd = new OleDbCommand(
                        "INSERT INTO tbl_Journal " +
                        "(StudentID, GroupID, DisciplineID, TeacherID, GradeDate, Grade) " +
                        "VALUES (?,?,?,?,?,?)", con))
                    {
                        cmd.Parameters.AddWithValue("?", studentId);
                        cmd.Parameters.AddWithValue("?", grp);
                        cmd.Parameters.AddWithValue("?", discId);
                        cmd.Parameters.AddWithValue("?", teachId);
                        cmd.Parameters.AddWithValue("?", d);
                        cmd.Parameters.AddWithValue("?", grade);
                        cmd.ExecuteNonQuery();
                    }
                }
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex) { Ui.Error(ex); }
        }
    }

    // ================================================================
    //  Изменить оценку (изменение записи журнала)
    // ================================================================
    public class FormEditGrade : Form
    {
        private int recordId;
        private Label lblStudent, lblGroup;
        private ComboBox cbDisc, cbTeach, cbGrade;
        private DateTimePicker dtp;

        public FormEditGrade(int recordId)
        {
            this.recordId = recordId;
            Ui.Dialog(this, "Изменить оценку", 400, 290);

            Controls.Add(Ui.MkLabel("Студент:", 15));
            lblStudent = new Label();
            lblStudent.Location = new Point(150, 15);
            lblStudent.AutoSize = true;
            lblStudent.Text = "-";
            Controls.Add(lblStudent);

            Controls.Add(Ui.MkLabel("Группа:", 48));
            lblGroup = new Label();
            lblGroup.Location = new Point(150, 48);
            lblGroup.AutoSize = true;
            lblGroup.Text = "-";
            Controls.Add(lblGroup);

            Controls.Add(Ui.MkLabel("Дисциплина:", 81));
            cbDisc = Form1.MakeCombo(
                "SELECT DisciplineID, DisciplineName FROM tbl_Discipline ORDER BY DisciplineName",
                "DisciplineName", "DisciplineID", false);
            cbDisc.Location = new Point(150, 78);
            cbDisc.Width = 230;
            Controls.Add(cbDisc);

            Controls.Add(Ui.MkLabel("Преподаватель:", 114));
            cbTeach = Form1.MakeCombo(
                "SELECT TeacherID, TeacherFIO FROM tbl_Teacher ORDER BY TeacherFIO",
                "TeacherFIO", "TeacherID", false);
            cbTeach.Location = new Point(150, 111);
            cbTeach.Width = 230;
            Controls.Add(cbTeach);

            Controls.Add(Ui.MkLabel("Дата:", 147));
            dtp = new DateTimePicker();
            dtp.Location = new Point(150, 144);
            dtp.Width = 230;
            dtp.Format = DateTimePickerFormat.Short;
            dtp.Value = DateTime.Today;
            Controls.Add(dtp);

            Controls.Add(Ui.MkLabel("Оценка:", 180));
            cbGrade = Ui.MkGradeCombo(150, 177);
            Controls.Add(cbGrade);

            Ui.Buttons(this, BtnOk_Click);
            LoadRecord();
        }

        private void LoadRecord()
        {
            try
            {
                DataTable dt = new DataTable();
                using (OleDbDataAdapter da = new OleDbDataAdapter(
                    "SELECT j.StudentID, s.LastName & ' ' & s.FirstName AS Student, j.GroupID, " +
                    "j.DisciplineID, j.TeacherID, j.GradeDate, j.Grade " +
                    "FROM tbl_Journal AS j LEFT JOIN tbl_Students AS s ON j.StudentID = s.StudentID " +
                    "WHERE j.RecordID=?", Db.ConnStr))
                {
                    da.SelectCommand.Parameters.AddWithValue("?", recordId);
                    da.Fill(dt);
                }
                if (dt.Rows.Count == 0) { Ui.Warn("Запись не найдена!", Text); Close(); return; }
                DataRow r = dt.Rows[0];
                lblStudent.Text = Convert.ToString(r["Student"]) + " (код " + r["StudentID"] + ")";
                lblGroup.Text = Convert.ToString(r["GroupID"]);
                if (r["DisciplineID"] != DBNull.Value) cbDisc.SelectedValue = Convert.ToInt32(r["DisciplineID"]);
                if (r["TeacherID"] != DBNull.Value) cbTeach.SelectedValue = Convert.ToInt32(r["TeacherID"]);
                if (r["GradeDate"] != DBNull.Value) dtp.Value = Convert.ToDateTime(r["GradeDate"]);
                if (r["Grade"] != DBNull.Value) cbGrade.SelectedValue = Convert.ToInt32(r["Grade"]);
            }
            catch (Exception ex)
            {
                Ui.Error(ex);
                Close();
            }
        }

        private void BtnOk_Click(object sender, EventArgs e)
        {
            if (cbDisc.SelectedIndex < 0) { Ui.Warn("Выберите дисциплину!", Text); return; }
            if (cbTeach.SelectedIndex < 0) { Ui.Warn("Выберите преподавателя!", Text); return; }
            if (!ValidationModule.ValidDate(dtp.Value.Date)) { Ui.Warn("Дата вне допустимого диапазона!", Text); return; }
            if (cbGrade.SelectedIndex < 0) { Ui.Warn("Выберите оценку!", Text); return; }
            int grade = Convert.ToInt32(cbGrade.SelectedValue);
            if (!ValidationModule.ValidGrade(grade)) { Ui.Warn("Оценка должна быть от 2 до 5!", Text); return; }
            try
            {
                using (OleDbConnection con = new OleDbConnection(Db.ConnStr))
                {
                    con.Open();
                    using (OleDbCommand cmd = new OleDbCommand(
                        "UPDATE tbl_Journal SET DisciplineID=?, TeacherID=?, GradeDate=?, Grade=? " +
                        "WHERE RecordID=?", con))
                    {
                        cmd.Parameters.AddWithValue("?", Convert.ToInt32(cbDisc.SelectedValue));
                        cmd.Parameters.AddWithValue("?", Convert.ToInt32(cbTeach.SelectedValue));
                        cmd.Parameters.AddWithValue("?", dtp.Value.Date);
                        cmd.Parameters.AddWithValue("?", grade);
                        cmd.Parameters.AddWithValue("?", recordId);
                        cmd.ExecuteNonQuery();
                    }
                }
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex) { Ui.Error(ex); }
        }
    }

    // ================================================================
    //  Составить списки студентов по группам (диаграмма состояний):
    //  сортировка по алфавиту / по среднему баллу,
    //  если студентов больше 30 - разбиение на части по 30 человек,
    //  вывод итоговых списков (сохранение в файл)
    // ================================================================
    public class FormListByGroup : Form
    {
        private ComboBox cbGroup;
        private RadioButton rbAlpha, rbGrade;
        private CheckBox chkSplit;
        private DataGridView grid;
        private Label lblCount;
        private DataTable students;
        private Dictionary<int, double?> avgByStudent;

        public FormListByGroup()
        {
            Text = "Списки студентов по группам";
            Font = new Font("Segoe UI", 9F);
            StartPosition = FormStartPosition.CenterParent;
            ClientSize = new Size(760, 520);

            Label lbl = new Label();
            lbl.Location = new Point(12, 15);
            lbl.AutoSize = true;
            lbl.Text = "Группа:";
            Controls.Add(lbl);

            cbGroup = Form1.MakeCombo(
                "SELECT GroupID, GroupID AS GVal FROM tbl_Groups ORDER BY GroupID",
                "GroupID", "GVal", false);
            cbGroup.Location = new Point(70, 12);
            cbGroup.Width = 150;
            cbGroup.DropDownStyle = ComboBoxStyle.DropDownList;
            Controls.Add(cbGroup);

            rbAlpha = new RadioButton();
            rbAlpha.Location = new Point(235, 14);
            rbAlpha.AutoSize = true;
            rbAlpha.Text = "По алфавиту";
            rbAlpha.Checked = true;
            Controls.Add(rbAlpha);

            rbGrade = new RadioButton();
            rbGrade.Location = new Point(335, 14);
            rbGrade.AutoSize = true;
            rbGrade.Text = "По среднему баллу";
            Controls.Add(rbGrade);

            chkSplit = new CheckBox();
            chkSplit.Location = new Point(480, 14);
            chkSplit.AutoSize = true;
            chkSplit.Text = "Части по 30 человек";
            Controls.Add(chkSplit);

            lblCount = new Label();
            lblCount.Location = new Point(12, 44);
            lblCount.AutoSize = true;
            lblCount.Text = "";
            Controls.Add(lblCount);

            grid = Ui.MkGrid(12, 68, 736, 400);
            Controls.Add(grid);

            Button btnSave = Ui.MkButton("Сохранить в файл", 538, 480, 110);
            btnSave.Click += BtnSave_Click;
            Controls.Add(btnSave);

            Button btnClose = Ui.MkButton("Закрыть", 656, 480, 92);
            btnClose.Click += delegate { Close(); };
            Controls.Add(btnClose);

            cbGroup.SelectedIndexChanged += delegate { LoadStudents(); };
            rbAlpha.CheckedChanged += delegate { Build(); };
            rbGrade.CheckedChanged += delegate { Build(); };
            chkSplit.CheckedChanged += delegate { Build(); };
            LoadStudents();
        }

        private string GroupId
        {
            get { return cbGroup.SelectedValue == null ? "" : Convert.ToString(cbGroup.SelectedValue); }
        }

        private void LoadStudents()
        {
            students = new DataTable();
            students.Columns.Add("StudentID", typeof(int));
            students.Columns.Add("FIO", typeof(string));
            avgByStudent = new Dictionary<int, double?>();
            if (GroupId.Length > 0)
            {
                try
                {
                    DataTable src = new DataTable();
                    using (OleDbDataAdapter da = new OleDbDataAdapter(
                        "SELECT StudentID, LastName & ' ' & FirstName AS FIO FROM tbl_Students " +
                        "WHERE GroupID=? ORDER BY LastName, FirstName", Db.ConnStr))
                    {
                        da.SelectCommand.Parameters.AddWithValue("?", GroupId);
                        da.Fill(src);
                    }
                    foreach (DataRow r in src.Rows)
                        students.Rows.Add(Convert.ToInt32(r["StudentID"]), Convert.ToString(r["FIO"]));

                    // средний балл каждого студента (сортировка по оценкам)
                    DataTable avg = new DataTable();
                    using (OleDbDataAdapter da = new OleDbDataAdapter(
                        "SELECT StudentID, AVG(Grade) AS AvgG FROM tbl_Journal " +
                        "GROUP BY StudentID", Db.ConnStr))
                        da.Fill(avg);
                    foreach (DataRow r in avg.Rows)
                        if (r["AvgG"] != DBNull.Value)
                            avgByStudent[Convert.ToInt32(r["StudentID"])] = Convert.ToDouble(r["AvgG"]);
                }
                catch (Exception ex) { Ui.Error(ex); }
            }
            // если студентов больше 30 - автоматически разбиваем на части
            chkSplit.Checked = students.Rows.Count > 30;
            Build();
        }

        private void Build()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("№", typeof(int));
            dt.Columns.Add("Студент", typeof(string));
            dt.Columns.Add("Ср. балл", typeof(string));
            if (chkSplit.Checked) dt.Columns.Add("Часть", typeof(int));

            IEnumerable<DataRow> rows = students.Rows.Cast<DataRow>();
            if (rbGrade.Checked)
            {
                rows = rows
                    .OrderByDescending(r => avgByStudent.ContainsKey((int)r["StudentID"]) ? avgByStudent[(int)r["StudentID"]] : double.MinValue)
                    .ThenBy(r => Convert.ToString(r["FIO"]));
            }
            else
            {
                rows = rows.OrderBy(r => Convert.ToString(r["FIO"]));
            }

            int i = 0;
            foreach (DataRow r in rows)
            {
                i++;
                int sid = Convert.ToInt32(r["StudentID"]);
                double? avg = avgByStudent.ContainsKey(sid) ? avgByStudent[sid] : (double?)null;
                List<object> vals = new List<object>();
                vals.Add(i);
                vals.Add(Convert.ToString(r["FIO"]));
                vals.Add(avg == null ? "-" : avg.Value.ToString("0.0"));
                if (chkSplit.Checked) vals.Add((i - 1) / 30 + 1);
                dt.Rows.Add(vals.ToArray());
            }

            lblCount.Text = "Всего студентов: " + i +
                (chkSplit.Checked && i > 0 ? "   (частей: " + (((i - 1) / 30) + 1) + ")" : "");
            grid.DataSource = dt;
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            DataTable dt = grid.DataSource as DataTable;
            if (dt == null || dt.Rows.Count == 0)
            {
                Ui.Warn("Список пуст - нечего сохранять!", Text);
                return;
            }
            List<string> lines = new List<string>();
            lines.Add("Составлен: " + DateTime.Now.ToString("dd.MM.yyyy HH:mm"));
            lines.Add(lblCount.Text);
            lines.Add(new string('-', 60));
            lines.Add("№   Студент                           Ср. балл" + (chkSplit.Checked ? "   Часть" : ""));
            foreach (DataRow r in dt.Rows)
            {
                if (chkSplit.Checked)
                    lines.Add(string.Format("{0,-4} {1,-34} {2,-8} {3}",
                        r["№"], r["Студент"], r["Ср. балл"], r["Часть"]));
                else
                    lines.Add(string.Format("{0,-4} {1,-34} {2}",
                        r["№"], r["Студент"], r["Ср. балл"]));
            }
            Ui.SaveTextReport(this, "Список студентов_" + GroupId + ".txt",
                "СПИСОК СТУДЕНТОВ ГРУППЫ " + GroupId, lines.ToArray());
        }
    }

    // ================================================================
    //  Расписание группы (вывод расписания и списка-отчёта)
    // ================================================================
    public class FormScheduleReport : Form
    {
        private ComboBox cbGroup;
        private DataGridView grid;
        private Label lblCount;

        public FormScheduleReport()
        {
            Text = "Расписание группы (сессия)";
            Font = new Font("Segoe UI", 9F);
            StartPosition = FormStartPosition.CenterParent;
            ClientSize = new Size(820, 520);

            Label lbl = new Label();
            lbl.Location = new Point(12, 15);
            lbl.AutoSize = true;
            lbl.Text = "Группа:";
            Controls.Add(lbl);

            cbGroup = Form1.MakeCombo(
                "SELECT GroupID, GroupID AS GVal FROM tbl_Groups ORDER BY GroupID",
                "GroupID", "GVal", false);
            cbGroup.Location = new Point(70, 12);
            cbGroup.Width = 150;
            cbGroup.DropDownStyle = ComboBoxStyle.DropDownList;
            Controls.Add(cbGroup);

            lblCount = new Label();
            lblCount.Location = new Point(240, 15);
            lblCount.AutoSize = true;
            lblCount.Text = "";
            Controls.Add(lblCount);

            grid = Ui.MkGrid(12, 44, 796, 420);
            Controls.Add(grid);

            Button btnSave = Ui.MkButton("Сохранить в файл", 604, 478, 105);
            btnSave.Click += BtnSave_Click;
            Controls.Add(btnSave);

            Button btnClose = Ui.MkButton("Закрыть", 715, 478, 93);
            btnClose.Click += delegate { Close(); };
            Controls.Add(btnClose);

            cbGroup.SelectedIndexChanged += delegate { LoadSchedule(); };
            LoadSchedule();
        }

        private string GroupId
        {
            get { return cbGroup.SelectedValue == null ? "" : Convert.ToString(cbGroup.SelectedValue); }
        }

        private void LoadSchedule()
        {
            DataTable dt = new DataTable();
            if (GroupId.Length > 0)
            {
                try
                {
                    using (OleDbDataAdapter da = new OleDbDataAdapter(
                        "SELECT s.ExamDate AS [Дата], s.ControlType AS [Вид], " +
                        "d.DisciplineName AS [Дисциплина], t.TeacherFIO AS [Преподаватель] " +
                        "FROM (tbl_SessionsSchedule AS s LEFT JOIN tbl_Discipline AS d ON s.DisciplineID = d.DisciplineID) " +
                        "LEFT JOIN tbl_Teacher AS t ON s.TeacherID = t.TeacherID " +
                        "WHERE s.GroupID=? ORDER BY s.ExamDate", Db.ConnStr))
                    {
                        da.SelectCommand.Parameters.AddWithValue("?", GroupId);
                        da.Fill(dt);
                    }
                }
                catch (Exception ex) { Ui.Error(ex); }
            }
            grid.DataSource = dt;
            foreach (DataGridViewColumn c in grid.Columns)
                if (c.ValueType == typeof(DateTime))
                    c.DefaultCellStyle.Format = "dd.MM.yyyy";
            lblCount.Text = "Всего мероприятий: " + dt.Rows.Count;
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            DataTable dt = grid.DataSource as DataTable;
            if (dt == null || dt.Rows.Count == 0)
            {
                Ui.Warn("Список пуст - нечего сохранять!", Text);
                return;
            }
            List<string> lines = new List<string>();
            lines.Add("Составлено: " + DateTime.Now.ToString("dd.MM.yyyy HH:mm"));
            lines.Add("Всего мероприятий: " + dt.Rows.Count);
            lines.Add(new string('-', 70));
            lines.Add(string.Format("{0,-12}{1,-12}{2,-30}{3}", "Дата", "Вид", "Дисциплина", "Преподаватель"));
            foreach (DataRow r in dt.Rows)
                lines.Add(string.Format("{0,-12}{1,-12}{2,-30}{3}",
                    Convert.ToDateTime(r["Дата"]).ToString("dd.MM.yyyy"),
                    Convert.ToString(r["Вид"]),
                    Convert.ToString(r["Дисциплина"]),
                    Convert.ToString(r["Преподаватель"])));
            Ui.SaveTextReport(this, "Расписание_" + GroupId + ".txt",
                "РАСПИСАНИЕ ЭКЗАМЕНОВ ГРУППЫ " + GroupId, lines.ToArray());
        }
    }

    // ================================================================
    //  Длительность сессии (запрос из версии 1 + расчёт дней
    //  из диаграммы последовательности)
    // ================================================================
    public class FormSessionDuration : Form
    {
        public FormSessionDuration()
        {
            Text = "Длительность сессии (запрос)";
            Font = new Font("Segoe UI", 9F);
            StartPosition = FormStartPosition.CenterParent;
            ClientSize = new Size(640, 430);

            Label lblInfo = new Label();
            lblInfo.Location = new Point(12, 12);
            lblInfo.AutoSize = false;
            lblInfo.Width = 600;
            lblInfo.Text = "Для каждой группы: начало сессии, конец и длительность в днях (включительно).";
            Controls.Add(lblInfo);

            DataGridView grid = Ui.MkGrid(12, 40, 616, 340);
            Controls.Add(grid);

            Button btnClose = Ui.MkButton("Закрыть", 531, 388, 97);
            btnClose.Click += delegate { Close(); };
            Controls.Add(btnClose);

            try
            {
                DataTable src = new DataTable();
                using (OleDbDataAdapter da = new OleDbDataAdapter(
                    "SELECT GroupID, MIN(ExamDate) AS StartDate, MAX(ExamDate) AS EndDate " +
                    "FROM tbl_SessionsSchedule GROUP BY GroupID ORDER BY GroupID", Db.ConnStr))
                    da.Fill(src);

                DataTable res = new DataTable();
                res.Columns.Add("Группа", typeof(string));
                res.Columns.Add("Начало сессии", typeof(DateTime));
                res.Columns.Add("Конец сессии", typeof(DateTime));
                res.Columns.Add("Длительность, дней", typeof(int));
                foreach (DataRow r in src.Rows)
                {
                    DateTime d1 = Convert.ToDateTime(r["StartDate"]);
                    DateTime d2 = Convert.ToDateTime(r["EndDate"]);
                    res.Rows.Add(r["GroupID"], d1, d2, (d2 - d1).Days + 1);
                }
                grid.DataSource = res;
                foreach (DataGridViewColumn c in grid.Columns)
                    if (c.ValueType == typeof(DateTime))
                        c.DefaultCellStyle.Format = "dd.MM.yyyy";
            }
            catch (Exception ex) { Ui.Error(ex); }
        }
    }
}
