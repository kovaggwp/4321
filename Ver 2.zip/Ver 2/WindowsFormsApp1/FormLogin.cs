﻿// =====================================================================
//  ИС "Деканат" (Вариант 7). Версия 2 - форма авторизации.
//
//  Форма входа в систему: логин + пароль. Проверка по таблице
//  tbl_Users. Если таблицы нет или она пуста - автоматически
//  создаётся и заполняется учётными записями по умолчанию.
//  Интерфейс строится программно (без дизайнера).
//
//  Учётные записи по умолчанию:
//    admin/admin      - Администратор
//    metodist/1234    - Методист
//    teacher/1234     - Преподаватель
//    student/1234     - Студент
// =====================================================================
using System;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public class FormLogin : Form
    {
        private TextBox txtLogin;
        private TextBox txtPass;
        private Button btnOk;

        public FormLogin()
        {
            BuildUi();
        }

        // ---------- построение интерфейса ----------
        private void BuildUi()
        {
            Text = "Авторизация - ИС Деканат (Вариант 7)";
            ClientSize = new Size(390, 210);
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            Font = new Font("Segoe UI", 9F);

            Label lblTitle = new Label();
            lblTitle.Text = "Информационная система \"Деканат\"";
            lblTitle.Location = new Point(12, 12);
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            Controls.Add(lblTitle);

            Label lblSub = new Label();
            lblSub.Text = "Вход в систему. Введите логин и пароль.";
            lblSub.Location = new Point(12, 37);
            lblSub.AutoSize = true;
            Controls.Add(lblSub);

            Label lblLogin = new Label();
            lblLogin.Text = "Логин:";
            lblLogin.Location = new Point(12, 73);
            lblLogin.AutoSize = true;
            Controls.Add(lblLogin);

            txtLogin = new TextBox();
            txtLogin.Location = new Point(120, 70);
            txtLogin.Width = 240;
            Controls.Add(txtLogin);

            Label lblPass = new Label();
            lblPass.Text = "Пароль:";
            lblPass.Location = new Point(12, 108);
            lblPass.AutoSize = true;
            Controls.Add(lblPass);

            txtPass = new TextBox();
            txtPass.Location = new Point(120, 105);
            txtPass.Width = 240;
            txtPass.UseSystemPasswordChar = true;
            Controls.Add(txtPass);

            btnOk = new Button();
            btnOk.Text = "Войти";
            btnOk.Location = new Point(120, 140);
            btnOk.Size = new Size(100, 30);
            btnOk.Click += BtnOk_Click;
            Controls.Add(btnOk);

            Button btnExit = new Button();
            btnExit.Text = "Выход";
            btnExit.Location = new Point(230, 140);
            btnExit.Size = new Size(100, 30);
            btnExit.Click += delegate { Close(); };
            Controls.Add(btnExit);

            Label lblInfo = new Label();
            lblInfo.Location = new Point(12, 182);
            lblInfo.Size = new Size(366, 20);
            lblInfo.ForeColor = Color.DimGray;
            lblInfo.Text = "admin/admin - администратор, metodist/1234 - методист, " +
                           "teacher/1234 - преподаватель, student/1234 - студент";
            Controls.Add(lblInfo);

            AcceptButton = btnOk;
            CancelButton = btnExit;
        }

        // ---------- вход в систему ----------
        private void BtnOk_Click(object sender, EventArgs e)
        {
            string l = txtLogin.Text.Trim();
            string p = txtPass.Text;
            if (l.Length == 0 || p.Length == 0)
            {
                MessageBox.Show("Введите логин и пароль!", "Авторизация",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            try
            {
                string role = null;
                using (OleDbConnection con = new OleDbConnection(Db.ConnStr))
                {
                    con.Open();
                    SyncUsersTable(con);

                    using (OleDbCommand cmd = new OleDbCommand(
                        "SELECT Role FROM tbl_Users WHERE LCase(Username)=? AND [Password]=?",
                        con))
                    {
                        cmd.Parameters.AddWithValue("?", l.ToLower());
                        cmd.Parameters.AddWithValue("?", p);
                        object res = cmd.ExecuteScalar();
                        if (res != null && res != DBNull.Value)
                            role = Convert.ToString(res);
                    }
                }

                if (role == null)
                {
                    MessageBox.Show("Неверный логин или пароль!", "Авторизация",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtPass.SelectAll();
                    txtPass.Focus();
                    return;
                }

                // Открываем главное окно с нормализованной ролью
                string roleKey = NormalizeRole(role);
                Hide();
                using (Form1 main = new Form1(l, roleKey))
                    main.ShowDialog(this);

                // Главное окно закрыто (кнопка "Сменить пользователя" или X) -
                // снова показываем форму входа.
                txtPass.Clear();
                Show();
                txtLogin.SelectAll();
                txtLogin.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Не удалось подключиться к базе данных:\n" + ex.Message +
                    "\n\nУбедитесь, что файл Деканат_Вариант7.accdb лежит в папке " +
                    "bin\\Debug (рядом с WindowsFormsApp1.exe),\nи что установлен " +
                    "Microsoft Access Database Engine (поставщик ACE OLEDB).",
                    "Ошибка подключения", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ---------- нормализация ролей ----------
        // Роль в БД может быть записана по-русски или по-английски -
        // приводим к единому ключу, который понимает Form1.
        public static string NormalizeRole(string role)
        {
            string r = (role == null ? "" : role).Trim().ToLower();
            switch (r)
            {
                case "administrator":
                case "администратор":
                    return "administrator";
                case "methodist":
                case "методист":
                case "деканат":
                    return "methodist";
                case "teacher":
                case "преподаватель":
                    return "teacher";
                default:
                    return "student";
            }
        }

        // ---------- синхронизация таблицы пользователей ----------
        // Если tbl_Users отсутствует или пуста - создаёт её и заполняет
        // учётными записями по умолчанию (чтобы вход был возможен сразу).
        private void SyncUsersTable(OleDbConnection con)
        {
            bool exists;
            try
            {
                using (OleDbCommand cmd = new OleDbCommand(
                    "SELECT COUNT(*) FROM tbl_Users", con))
                    Convert.ToInt32(cmd.ExecuteScalar());
                exists = true;
            }
            catch { exists = false; }

            if (!exists)
            {
                using (OleDbCommand cmd = new OleDbCommand(
                    "CREATE TABLE tbl_Users (" +
                    "UserID COUNTER PRIMARY KEY, " +
                    "Username TEXT(50), " +
                    "[Password] TEXT(50), " +
                    "Role TEXT(50))", con))
                    cmd.ExecuteNonQuery();
            }

            int cnt;
            using (OleDbCommand cmd = new OleDbCommand(
                "SELECT COUNT(*) FROM tbl_Users", con))
                cnt = Convert.ToInt32(cmd.ExecuteScalar());
            if (cnt > 0) return;

            string[][] defaults = new string[][]
            {
                new string[] { "admin",    "admin", "Администратор"  },
                new string[] { "metodist", "1234",  "Методист"       },
                new string[] { "teacher",  "1234",  "Преподаватель"  },
                new string[] { "student",  "1234",  "Студент"        }
            };
            foreach (string[] u in defaults)
            {
                using (OleDbCommand cmd = new OleDbCommand(
                    "INSERT INTO tbl_Users (Username, [Password], Role) VALUES (?,?,?)",
                    con))
                {
                    cmd.Parameters.AddWithValue("?", u[0]);
                    cmd.Parameters.AddWithValue("?", u[1]);
                    cmd.Parameters.AddWithValue("?", u[2]);
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}
